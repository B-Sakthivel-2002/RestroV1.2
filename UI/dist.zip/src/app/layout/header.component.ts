import { Component, OnInit } from '@angular/core';
import { CommonModule,NgFor } from '@angular/common';
import { QueryService } from '@appservices/query.service';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '@appservices/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule,RouterModule],
  template: `
    <header class="custom-navbar-bg">
        <nav class="navbar navbar-expand-lg bg-white">
          <div class="container-fluid">
            <div class="custom-brand"> 
              <a class="navbar-brand" href="/dashboard">Restaurant</a>              
            </div>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navSupportLogoId" aria-controls="navSupportLogoId" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
              
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navSupportLogoId">

            <!-- <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link " aria-current="page" href="#">
                    <i class="pi pi-search icon"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <i class="pi pi-th-large icon"></i>
                  </a>
                </li>
              </ul>  -->
             
            <ul class="navbar-nav">
                <!-- <li class="nav-item">
                  <a class="nav-link " aria-current="page" href="#">
                    <i class="pi pi-calendar-plus icon"></i>
                  </a>
                </li> -->
                @for(list of menuList;track list.name){

                  <!-- {{list.submenu.length}} -->
                 

                  @if(list.submenu.length!=0){
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="sb-tt">{{list.name}}</span>
                        <i [class]="list.icon"></i>
                        <!-- <img src="/assets/images/profileImage.png"  class="custom-image"/> -->
                      </a>
                    <ul class="dropdown-menu dropdown-menu-end">  
                      @for(sublist of list.submenu; track sublist.name)   {
                        @if(sublist.name=='Logout'){
                           <li><span class="dropdown-item" (click)="logout()">1{{sublist.name}}</span></li>
                        }@else{
                         <li><a class="dropdown-item" [href]="sublist.url">{{sublist.name}}</a></li>
                        }
                      }  
                    </ul>
                  </li>
                  }@else{
                    <li class="nav-item">
                    <a class="nav-link" [routerLink]="[list.url]" >
                      <i [class]="list.icon"></i>
                      <span>{{list.name}}</span>
                    </a>
                  </li>
                  }
                }
                
            


              </ul>  

            </div>
          </div>
      </nav>
    </header>
  `,
  styles: ``
})
export class HeaderComponent implements OnInit {

  imagePath:any;
  menuList:any[]=[];

  constructor(private queryService:QueryService,private auth:AuthService,private router:Router){}
  ngOnInit(): void {
    this.loadMenu();
  //  throw new Error('Method not implemented.');
  }


  loadMenu(){
    this.queryService.getMenuList().subscribe({
      next:((res:any)=>{
        console.log(res,'res');
        if(res.status=='success'){
          this.menuList =  res.menu;
        }
        console.log(this.menuList,'this.menuList');
      }),
      error:((res:any)=>{

      })
    })
  }

  logout(){

    this.auth.clearRolesToken().subscribe({
      next:((res:any)=>{

        if(res){
          this.router.navigate(['/']);
        }

      }),
      error:((err:any)=>{

        // this.alert

      })

    })

  }

}
