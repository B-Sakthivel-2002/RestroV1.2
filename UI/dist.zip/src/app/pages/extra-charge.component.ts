import { Component,OnInit, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '@applayout/header.component';
import { QueryService } from '@appservices/query.service';
import { ReactiveFormsModule, FormBuilder, FormGroup, Form, Validators } from '@angular/forms';
import { StateService } from '@appservices/state.service';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from '@appservices/alert.service';
import { debounceTime } from 'rxjs';



@Component({
  selector: 'app-extra-charge',
  standalone: true,
  imports: [HeaderComponent,CommonModule,ReactiveFormsModule],
  providers:[BsModalService,AlertService],
  template: `
  <app-header></app-header>
  <div class="wrapper">
            <div class="right-side">
              <div class="sub-header">
                  <div class="tt">
                    <h2 class="mn-tt">Extra Charge</h2>
                  </div>  
                  <div class="btn-bg">
                    <button type="button" class="btn btn-primary" (click)="openModal(extraChargeTemplate);setextraChargeList('create',0);">+ Create Extra Charge</button> 
                  </div>           
              </div>
              <div class="cnt">
                <table class="table custom-table">
                    <thead>
                      <tr>                        
                        <th scope="col">Id</th>                       
                        <th scope="col">Extra Charge Name</th>   
						            <th scope="col">Extra Charge Rate</th> 
                        <th>Extra Charge Type</th>
                        <th>Range status</th>
                        <th scope="col">Range From</th> 
                        <th scope="col">Range To</th> 
                        <th scope="col" style="width:200px" >Action</th>
                      </tr>
                    </thead>
                    <tbody>

                    @for(fs of extraChargeList; track fs.extraChargeid){
                      <tr>
                       
                          <td>{{fs.extraChargeid}}</td>
                          <td>{{fs.extraChargename}}</td>     
						              <td>{{fs.extraChargerate}}</td>     		
                         <td>{{fs.extraChargetype}}</td> 
                           <td>{{fs.extraChargerangestatus}}</td> 
                          <td>{{fs.extraChargefrom ? fs.extraChargefrom :'-'}}</td> 
                          <td>{{fs.extraChargeto ? fs.extraChargeto :'-'}}</td> 
                          <td class="custom-btn">  
                            <button type="button" class="btn btn-primary" (click)="setextraChargeList('edit',fs.extraChargeid);openModal(extraChargeTemplate);">
                                <i class="pi pi-file-edit " ></i>
                            </button>
                            <button type="button" class="btn btn-danger" (click)="getConfirmMessage(fs.extraChargeid)">
                                <i class="pi pi-trash " ></i>
                            </button>
                          </td>
                      </tr>
                    }
                      
                      
                    </tbody>
                  </table>
              </div>              
            </div>


    </div>

    
     
     <ng-template #extraChargeTemplate>
       <div class="modal-header">
         <h4 class="modal-title pull-left">{{extraChargeFormTitle}} Extra Charge</h4>
         <button type="button" class="btn-close close pull-right" aria-label="Close" (click)="extraChargeModalRef?.hide();">
           <span aria-hidden="true" class="visually-hidden">&times;</span>
         </button>
       </div>
       <div class="modal-body">
          <form  [formGroup]="extraChargeForm"  *ngIf="extraChargeForm"> 
            
            <div class="row mb-3">

              <div class="col-md-4">
                <label for="extraChargename" name="extraChargename" class="col-form-label">Extra Charge Name</label>
                <input type="text" value="" class="form-control" formControlName="extraChargename" />
                <div *ngIf="extraChargeForm.get('extraChargename')?.invalid && extraChargeForm.get('extraChargename')?.touched">
                  <small class="text-danger">Extra Charge name is required.</small>
                </div>
              </div>
              <div class="col-md-4">
                <label for="extraChargerate" name="extraChargerate" class="col-form-label">Extra Charge rate</label>
                <input type="text" value="" class="form-control" formControlName="extraChargerate" />
                <div *ngIf="extraChargeForm.get('extraChargerate')?.invalid && extraChargeForm.get('extraChargerate')?.touched">
                  <small class="text-danger">Extra Charge rate is required.</small>
                </div>
              </div>

              <div class="col-md-4">
                <label for="extraChargerangestatus" name="extraChargerangestatus" class="col-form-label" >
                   <input type="checkbox" value ="" formControlName="extraChargerangestatus" />
                  Enable Extra Charge Range</label>
                  
              </div>

            </div>
			
            <div class="row mb-3">


                 <div class="col-md-4">
                 
                <label for="extraChargetype" name="extraChargetype" class="col-form-label" >Extra Charge Type</label>
                <select id="extraChargetype" formControlName="extraChargetype" class="form-control">
                   <option value="percentage" >Percentage (%)</option>
                  <option value="flat">Flat (₹)</option>
                </select>
                <div *ngIf="extraChargeForm.get('extraChargetype')?.invalid && extraChargeForm.get('extraChargetype')?.touched">
                  <small class="text-danger">Extra Charge type is required.</small>
                </div>
              </div>

              <div class="col-md-4">
                <label for="extraChargefrom" name="extraChargefrom" class="col-form-label" >From</label>
                <input type="number" formControlName="extraChargefrom" class="form-control"  />
                <div *ngIf="extraChargeForm.get('extraChargefrom')?.invalid && extraChargeForm.get('extraChargefrom')?.touched ">
                  <small class="text-danger">range from is required.</small>
                </div>
              </div>

              <div class="col-md-4">
                <label for="extraChargeto" name="extraChargeto" class="col-form-label" >To</label>
                <input type="number" formControlName="extraChargeto"  class="form-control" />
                <div *ngIf="extraChargeForm.get('extraChargeto')?.invalid && extraChargeForm.get('extraChargeto')?.touched ">
                  <small class="text-danger">range to is required.</small>
                </div>
              </div>   
            </div>

            <div class="row mb-3">              
              <div *ngIf="extraChargeForm.errors">                   
                  <small *ngIf="extraChargeForm.errors?.['extraChargeRangeInvalid']">Extra Charge From must be less than Extra Charge To</small>
                </div>
            </div>
			
            </form>
       </div>
       <div class="modal-footer"  *ngIf="extraChargeForm">
            <button type="submit" [disabled]="extraChargeForm.invalid" class="btn btn-primary" (click)="onHandleSubmit()">Save</button>            
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" (click)="extraChargeModalRef?.hide()">Close</button>
          </div>
     </ng-template>   
  `,
  styles: ``
})
export class ExtraChargeComponent {

  extraChargeList:any=[];  
  extraChargeForm!:FormGroup;
  extraChargeFormTitle:String ='Create';
  extraChargeModalRef?: BsModalRef;

  initialextraChargeValues ={
      extraChargeid:0,
      extraChargename:'',
		  extraChargerate:0,
      extraChargetype: 'percentage',
      extraChargerangestatus:false,
      extraChargefrom: '',
      extraChargeto: ''
  }
  constructor(private changeDetectRef:ChangeDetectorRef,private alertService: AlertService,private modalService: BsModalService,private query:QueryService,private fb:FormBuilder,private cdref: ChangeDetectorRef,private stateService:StateService){

  }

  ngOnInit(): void {
    
    this.getextraChargeList();

    this.extraChargeForm = this.fb.group({   
      extraChargeid:[this.initialextraChargeValues.extraChargeid],
        extraChargename:[this.initialextraChargeValues.extraChargename,Validators.required],
		    extraChargerate:[this.initialextraChargeValues.extraChargerate,[Validators.required,
          Validators.pattern(/^\d+(\.\d{1,2})?$/)  // Accepts numbers like 10.00
        ]],
        extraChargetype:[this.initialextraChargeValues.extraChargetype,Validators.required],
        extraChargerangestatus:[this.initialextraChargeValues.extraChargerangestatus,Validators.required],
        extraChargefrom:[this.initialextraChargeValues.extraChargefrom],
        extraChargeto:[this.initialextraChargeValues.extraChargeto]
    })

   this.validateRangeStatus();

  }


  validateRangeStatus(){

    this.extraChargeForm.get('extraChargerangestatus')?.valueChanges.subscribe((status: boolean) => {

        const extraChargefrom = this.extraChargeForm.get('extraChargefrom');
        const extraChargeto = this.extraChargeForm.get('extraChargeto');

        if(status){
          extraChargefrom?.setValidators([Validators.required]);
          extraChargeto?.setValidators([Validators.required])
        }else{
          extraChargefrom?.clearValidators();
          extraChargeto?.clearValidators();
          extraChargefrom?.setValue(this.initialextraChargeValues.extraChargefrom);
          extraChargeto?.setValue(this.initialextraChargeValues.extraChargeto);
        }

        extraChargefrom?.updateValueAndValidity();
        extraChargeto?.updateValueAndValidity();
      
    });

    this.extraChargeForm.get('extraChargefrom')?.valueChanges.pipe(debounceTime(100)).subscribe(()=>{
      this.checkextraChargeRangeValidity();
    })

    this.extraChargeForm.get('extraChargeto')?.valueChanges.pipe(debounceTime(100)).subscribe(()=>{
      this.checkextraChargeRangeValidity();
    })

  }

  checkextraChargeRangeValidity() {
    const status = this.extraChargeForm.get('extraChargerangestatus')?.value;
    const from = parseFloat(this.extraChargeForm.get('extraChargefrom')?.value);
    const to = parseFloat(this.extraChargeForm.get('extraChargeto')?.value);

    console.log(status,from,to,!isNaN(from),!isNaN(to),'--->status --from -- to')

    const currentErrors = this.extraChargeForm.errors || {};

      if (from >= to && status) {
        this.extraChargeForm.setErrors({ ...currentErrors, extraChargeRangeInvalid: true });
      } else {
        const { extraChargeRangeInvalid, ...others } = currentErrors;
        const newErrors = Object.keys(others).length > 0 ? others : null;
        this.extraChargeForm.setErrors(newErrors);
      }
  }

  openModal(template: TemplateRef<void>) {
    if (!template) {
      console.error('TemplateRef is undefined');
      return;
    }
    this.extraChargeModalRef = this.modalService.show(template);
  }
  

  getextraChargeList(){    
    this.stateService.setLoadingState(true);
   
    this.query.getExtraCharges().subscribe({
      next:((res:any)=>{
        this.extraChargeList = res.data;
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      complete: () => this.stateService.setLoadingState(false)
    })
    
  }

  
  getConfirmMessage(id:Number){
    this.alertService.showAlert('Confirmation !','Do you want to delete the extraCharge',()=>{
      console.log('confirmed');
      this.deleteextraChargeList(id);
    });
  }


  deleteextraChargeList(id:Number){
    this.stateService.setLoadingState(true);
    this.query.deleteExtraCharge(id).subscribe({
      next:((res:any)=>{
        console.log(res,'result');
        this.getextraChargeList();
        this.changeDetectRef.detectChanges();
        this.alertService.showAlert('Alert !','extraCharge has been deleted');
      }),
      error:((err:any)=>{
        console.log(err,'err');
        this.stateService.setLoadingState(false);
        this.alertService.showAlert('Error !',err.message);
      }),
      complete: (() => {
        console.log('completed');        
      })
    })
    this.stateService.setLoadingState(false);
  }


  setextraChargeList(flag: string, inputId: number) {

    this.extraChargeFormTitle = flag;
  
    if (flag === 'create') {
     //  this.taxForm.reset(this.initialTaxFormValues);
      this.extraChargeForm.reset(this.initialextraChargeValues);
      console.log(this.extraChargeForm);
    } else if (flag === 'edit') {
      const localextraChargeForm = this.extraChargeList.filter((x: any) => x.extraChargeid === inputId);
  
      if (localextraChargeForm && localextraChargeForm.length > 0) {
        this.extraChargeForm.patchValue({
          extraChargeid: localextraChargeForm[0].extraChargeid,
          extraChargename: localextraChargeForm[0].extraChargename,
		  extraChargerate: localextraChargeForm[0].extraChargerate
        });
      } else {
        console.error('extraCharge data not found for id:', inputId);
      }
    }
    //this.openModal(extraChargeTemplate);
  }

  onHandleSubmit() {
    this.stateService.setLoadingState(true);
    if (this.extraChargeForm.valid) {      
      const outputParams = this.extraChargeForm.value;
      console.log(outputParams, 'outputParams');

      const request$ =  outputParams.extraChargeid && outputParams.extraChargeid !== 0 ? this.query.updateExtraCharge(outputParams) :this.query.addExtraCharge(outputParams)

      request$.subscribe({
        next: (res: any) => {
          console.log(res, '--set-categories');
          this.extraChargeModalRef?.hide();
          this.getextraChargeList(); // Refresh list
          this.changeDetectRef.detectChanges();
          this.stateService.setLoadingState(false);
          this.alertService.showAlert('Success!','tax has been updated successfully');  
        },
        error: (err: any) => {
           this.extraChargeModalRef?.hide();
          this.stateService.setLoadingState(false);
          this.alertService.showAlert('Error!',err.message);
          console.error(err, '--err-categories');
        },
        complete: () => {
          this.stateService.setLoadingState(false);
        }
      });

    }

  

  }
  
  
}
