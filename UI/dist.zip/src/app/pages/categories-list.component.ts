import { Component,OnInit, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '@applayout/header.component';
import { QueryService } from '@appservices/query.service';
import { ReactiveFormsModule, FormBuilder, FormGroup, Form, Validators } from '@angular/forms';
import { StateService } from '@appservices/state.service';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from '@appservices/alert.service';


@Component({
  selector: 'app-categories-list',
  standalone: true,
  imports: [HeaderComponent,CommonModule,ReactiveFormsModule],
  providers:[BsModalService,AlertService],
  template: `
  <app-header></app-header>
  <div class="wrapper">
            <div class="right-side">
              <div class="sub-header">
                  <div class="tt">
                    <h2 class="mn-tt">Categories</h2>
                  </div>  
                  <div class="btn-bg">
                    <button type="button" class="btn btn-primary" (click)="openModal(categoryTemplate);setCategoiresDetail('create',0);">+ Add Category</button> 
                  </div>           
              </div>
              <div class="cnt">
                <table class="table custom-table">
                    <thead>
                      <tr>      
                        <th scope="col">Branch Id</th>                       
                        <th scope="col">Category Id</th>
                        <th scope="col">Category Name</th> 
                        <th scope="col">Status</th>                       
                        <th scope="col" style="width:200px" >Action</th>
                      </tr>
                    </thead>
                    <tbody>

                    @for(fs of categoriesList; track fs.categoiresId){
                      <tr>
                          <td>{{fs.branchid}}</td>
                          <td>{{fs.categoryid}}</td>
                          <td>{{fs.categoryname}}</td>
                           <td [ngClass]="fs.flag ? 'status-on' : 'status-off'">{{fs.flag ? 'On' : 'Off'}}</td>
                          <td class="custom-btn">  
                            <button type="button" class="btn btn-primary" (click)="setCategoiresDetail('edit',fs.categoryid);openModal(categoryTemplate);">
                                <i class="pi pi-file-edit " ></i>
                            </button>
                            <button type="button" class="btn btn-danger" (click)="getConfirmMessage(fs.categoryid)">
                                <i class="pi pi-trash " ></i>
                            </button>
                          </td>
                      </tr>
                    }
                      
                      
                    </tbody>
                  </table>
              </div>              
            </div>


    </div>

    
     
     <ng-template #categoryTemplate>
       <div class="modal-header">
         <h4 class="modal-title pull-left">{{categoiresFormTitle}} category</h4>
         <button type="button" class="btn-close close pull-right" aria-label="Close" (click)="categoryModalRef?.hide();">
           <span aria-hidden="true" class="visually-hidden">&times;</span>
         </button>
       </div>
       <div class="modal-body">
          <form  [formGroup]="categoiresForm"  *ngIf="categoiresForm"> 

            <div class="row mb-3">
              <div class="col-md-12">
                <label for="categoryname" name="categoryname" class="col-form-label">Category Name</label>
                <input type="text" value="" class="form-control" formControlName="categoryname" />
                <div *ngIf="categoiresForm.get('categoryname')?.invalid && categoiresForm.get('categoryname')?.touched">
                  <small class="text-danger">category name is required.</small>
                </div>
              </div>                         
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="branchid" name="branchid" class="col-form-label">Branch Id</label>
                <select formControlName="branchid">
                  @for(br of branchList; track br.branchid){
                    <option [value]="br.branchid">{{br.branchname}}</option>
                  }                    
                  </select>
              </div>
              <div class="col-md-6">
                <label for="flag" name="flag" class="col-form-label">Status</label>
                <input type="checkbox" value="" formControlName="flag" />
              </div>
            </div>

            </form>
       </div>
       <div class="modal-footer"  *ngIf="categoiresForm">
            <button type="submit" [disabled]="categoiresForm.invalid" class="btn btn-primary" (click)="onHandleSubmit()">Save</button>            
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" (click)="categoryModalRef?.hide()">Close</button>
          </div>
     </ng-template>   
  `,
  styles: ``
})
export class CategoriesListComponent {
  categoriesList:any=[];  
  categoiresForm!:FormGroup;
  categoiresFormTitle:String ='Create';
  categoryModalRef?: BsModalRef;
  branchList:any[]=[];
  initialCategoryForm ={
      categoryid:0,
      categoryname:'',
      branchid:1,
      flag:true    
  }
  constructor(private alertService: AlertService,private modalService: BsModalService,private query:QueryService,private fb:FormBuilder,private cdref: ChangeDetectorRef,private stateService:StateService){

  }

  ngOnInit(): void {
    
    this.getCategoriesList();
    this.getBranchList();

    this.categoiresForm = this.fb.group({	
      categoryid:[this.initialCategoryForm.categoryid],
      categoryname:[this.initialCategoryForm.categoryname,Validators.required],
      branchid:[this.initialCategoryForm.branchid,Validators.required],
      flag:[this.initialCategoryForm.flag,Validators.required  ]    
    })
  }


    getBranchList(){

    this.stateService.setLoadingState(true);

    this.query.getBranchList().subscribe({
      next:((res:any)=>{
        console.log(res,'--get-branch-res');
        this.branchList = res.data;
        this.stateService.setLoadingState(false);
        
      }),
      error:((err:any)=>{
        console.log(err);
        this.stateService.setLoadingState(false);
      })
    })

  }

  openModal(template: TemplateRef<void>) {
    if (!template) {
      console.error('TemplateRef is undefined');
      return;
    }
    this.categoryModalRef = this.modalService.show(template);
  }
  

  getCategoriesList(){    
    this.stateService.setLoadingState(true);
   
    this.query.getCategories().subscribe({
      next:((res:any)=>{
        this.categoriesList = res.data;
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      complete: () => this.stateService.setLoadingState(false)
    })
    
  }

  
  getConfirmMessage(id:Number){
    this.alertService.showAlert('Confirmation !','Do you want to delete the category',()=>{
      console.log('confirmed');
      this.deleteCategoiresDetail(id);
    });
  }


  deleteCategoiresDetail(id:Number){
    this.stateService.setLoadingState(true);
    this.query.deletecategory(id).subscribe({
      next:((res:any)=>{
        console.log(res,'result');
        this.getCategoriesList();
        this.alertService.showAlert('Alert !','Category has been deleted');
      }),
      error:((err:any)=>{
        console.log(err,'err');
        this.stateService.setLoadingState(false);
        this.alertService.showAlert('Error !',err.message);
      }),
      complete: (() => {
        console.log('completed');        
      })
    })
    this.stateService.setLoadingState(false);
  }


  setCategoiresDetail(flag: string, inputId: number) {

    this.categoiresFormTitle = flag;
  
    if (flag === 'create') {
      this.categoiresForm.reset(this.initialCategoryForm);
    } else if (flag === 'edit') {
      const localcategoiresForm = this.categoriesList.filter((x: any) => x.categoryid === inputId);
  
      if (localcategoiresForm && localcategoiresForm.length > 0) {
        this.categoiresForm.patchValue({
          categoryid: localcategoiresForm[0].categoryid,
          categoryname: localcategoiresForm[0].categoryname,
        });
      } else {
        console.error('Category data not found for id:', inputId);
      }
    }
    //this.openModal(categoryTemplate);
  }

  onHandleSubmit() {
    this.stateService.setLoadingState(true);
    if (this.categoiresForm.valid) {
      
      const outputParams = this.categoiresForm.value;

      console.log(outputParams, 'outputParams');

      const request$ = outputParams.categoryid && outputParams.categoryid !==0 ? this.query.updateCategory(outputParams): this.query.addCategory(outputParams);

      request$.subscribe({
        next: (res: any) => {
          console.log(res, '--set-categories');
          this.categoryModalRef?.hide();
          this.getCategoriesList(); // Refresh list
        },
        error: (err: any) => {
          this.categoryModalRef?.hide();
          console.error(err, '--err-categories');
        },
        complete: () => this.stateService.setLoadingState(false)
      });
     
    }
    if(this.categoiresFormTitle=='create'){
      this.alertService.showAlert('Success!','Category has been created successfully');
    }else{
      this.alertService.showAlert('Success!','Category has been updated successfully');
    }

  }
  
  
}
