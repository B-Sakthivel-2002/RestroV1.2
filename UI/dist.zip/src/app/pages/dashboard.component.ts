import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
//import { HeaderComponent } from '../layout/header.component';
import {HeaderComponent} from '@applayout/header.component';
import { QueryService } from '@appservices/query.service';
import { async, from } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';



@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [HeaderComponent,CommonModule,FormsModule,RouterModule],
  template: `
    <app-header></app-header>
    <div class="wrapper">
        <div class="right-side">
        <div class="sub-header">
          <div class="tt"><h2 class="cs-mn-tt">Sale Report</h2></div>
          <div class="btn-bg spl-bg">
                <div class="fl-spl-bg">     
                  <div class="dt-bg">     
                    <label class="ssb-tt">From Date</label>      
                    <input type="date" class="form-control" [(ngModel)]="post.fromDate" />
                  </div>
                   <div class="dt-bg">     
                    <label class="ssb-tt">To Date</label>      
                     <input type="date" class="form-control" [(ngModel)]="post.toDate"/>
                  </div>
                  <div class="dt-bg">     
                    <label class="ssb-tt">Payment Status</label>      
                     <select class="form-control" [(ngModel)]="post.status">
                  <option value="all" default>All</option>
                  <option value="paid">paid</option>
                  <option value="unpaid"> unpaid</option>
                </select>
                  </div>
               
                
                <button (click)="getOrderByDate()" class="btn btn-primary">Submit</button>
                 <button (click)="TodayDate()" class="btn btn-danger"><i class="pi pi-refresh"></i></button>
                <button (click)="TodayDate()" class="btn btn-danger"><i class="pi pi-calendar-clock"></i></button>
                </div>
          </div>
        </div>
        <div class="cnt">

            <div class="row">
              <div class="col-8 cs-tab">

                      <ul class="nav nav-pills" role="tablist">
                          <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="bill-summary-tab" data-bs-toggle="pill" data-bs-target="#bill-summary" type="button" role="tab" aria-controls="bill-summary" aria-selected="true">Bills</button>
                          </li>
                          <li class="nav-item" role="presentation">
                            <button class="nav-link" id="order-summary-tab" data-bs-toggle="pill" data-bs-target="#order-summary" type="button" role="tab" aria-controls="order-summary" aria-selected="false">Order</button>
                          </li>
                      </ul>
                    <div class="tab-content " id="summary-content">
                      <div class="tab-pane fade show active" id="bill-summary" role="tabpanel" aria-labelledby="bill-summary-tab">
                       <div class="custom-table-bg">
                          <h3 class="cs-mn-tt">Bill Summary</h3>
                          <div class="fl-bg">
                            <div class="ls">
                              <label>Bill ID</label>
                              <input type="text" value="" class="form-control" [(ngModel)]="billFilter.billId" (ngModelChange)="billFilterList()" />
                            </div>
                            <div class="ls">
                              <label>Total Amount</label>
                              <input type="text" value="" class="form-control"  [(ngModel)]="billFilter.totalAmount" (ngModelChange)="billFilterList()" />
                            </div>
                            <div class="ls">
                               <label>Bill Status</label>
                                <select class="form-select" 
                                      (ngModelChange)="billFilterList()" 
                                      [(ngModel)]="billFilter.status" (change)="onChangeFilter($event)" >

                                  <option value="">All</option>
                                  <option value="printed">Printed</option>
                                  <option value="finalized">Finalized</option>
                                  <option value="complementary">Complementary</option>
                              </select>
                            </div>                            
                            
                          </div>
                         
                          <table class="table custom-table">
                            <thead>
                              <tr>
                                  <th>Bill Id</th>
                                  <th>Bill Number</th>                                
                                  <th>Business Date</th>
                                  <th>Sub Total Amount</th>                                  
                                  <th>Tax</th>                
                                  <th>Discount</th>
                                   <th>Extra Charges</th>
                                    <th>Total Amount</th>   
                                    <th>Bill Status</th>
                                     <th>Payment Status</th>
                                     <th>Branch</th>   
                                  <!-- <th>Orders</th> -->
                                </tr>
                            </thead>
                            <tbody>                  
                                @for(bl of orderlist; track bl.billid){
                                    <tr>
                                      <td>{{bl.billid}}</td>
                                      <td>{{bl.billnumber}}</td>
                                      <!-- <td>{{bl.datetime	 | date: 'dd-MM-yyyy'}}</td> -->
                                      <td>{{bl.businessdate | date:'dd-MM-yyyy'}}</td>                                                     
                                      <td>{{bl.subtotal}}</td>                                     
                                      <td>{{bl.tax}}</td>                       
                                      <td>{{bl.discount}}</td>
                                      <td>{{bl.extraamount}}</td>
                                       <td>{{bl.totalamount}}</td>   
                                      <td class="txt-camel">{{bl.lifecyclestatus }}</td>
                                       <td>{{bl.status}}</td>
                                       <td>{{bl.branch}}</td>
                                      <!-- <td>
                                        <button class="btn btn-primary">
                                          <i class="pi pi-file-o"></i>
                                      </button></td> -->
                                    </tr>
                                }@empty {
                                  <tr>
                                      <td colspan="12" class="text-center">No data found </td>
                                  </tr>
                                }
                            </tbody>
                          </table>
                          </div>
                      </div>
                       <div class="tab-pane fade" id="order-summary" role="tabpanel" aria-labelledby="order-summary">
                         <h3 class="cs-mn-tt">Order Summary</h3>
                      </div>
                    </div>
                        
                       </div>

              <div class="col-md-4">
                  <h3 class="cs-spl-tt">Selected Bill Date : ({{ post.fromDate | date:'dd-MM-YYYY'}} - {{ post.toDate | date:'dd-MM-YYYY'}})</h3>
                  <table class="table custom-table">
                    <thead>                     
                      <tr>
                        <th>Name</th>   
                        <th>Sub Total</th>
                         <th>Tax</th>
                         <th>Total (with tax)</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                      @for(bl of orderTypeWise; track bl.orderTypeId){
                        <tr>
                          <td>{{bl.ordertype}}</td>                          
                           <td>{{bl.subTotalAmount}}</td>
                           <td>{{bl.totalTax}}</td>
                           <td>{{bl.totalOrderAmount}}</td>
                        </tr>
                      }@empty {
                        <tr>
                          <td colspan="4">No data found</td>
                        </tr>
                      }

                      @if(this.totalEarnings.totalAmount){
                        <tr>
                          <td>Total</td>
                          <td class="txt-blue"><b>{{totalEarnings.subTotal}}</b></td>
                          <td class="txt-blue">{{totalEarnings.totalAmount}}</td>
                          <td class="txt-blue"><b>{{totalEarnings.totalAmount}}</b></td>
                        </tr>
                        <tr>
                          <td  class="bg-black">Unpaid</td>
                          <td  class="bg-black"> {{totalEarnings.subTotal}}</td>                          
                          <td  class="bg-green">Paid</td>
                          <td  class="bg-green">{{totalEarnings.totalAmount}}</td>
                        </tr>

                         <tr>
                          <td colspan="2" class="bg-grey" >Complementary</td>
                          <td colspan="2"  class="bg-grey">{{totalEarnings.subTotal}}</td>  
                        </tr>
                      }
                      

                    </tbody>
                  </table>

                 <a [routerLink]="['/open-close-day']" class="btn btn-danger">
                    Open/Close Work Period
                  </a>
                  <a [routerLink]="['/kot-list']" class="btn btn-primary">
                    KOT List
                  </a>

              </div>

                
            </div>

           

            
        </div>
       
          
        </div>
    </div>
  `,
  styles: ``
})
export class DashboardComponent implements OnInit {


  orderlist:any;
  orderListSource:Array<any>=[];
  orderTypeWise:Array<any>=[];
  totalEarnings:any={
    totalAmount:'',
    billAmount:''
  }

 post: any = {
  fromDate: this.formatDate(new Date()),
  toDate: this.formatDate(new Date()),
  status: 'all'
};

billFilter:any={
  billId:'',
  totalAmount:'',
  status:''
}

onChangeFilter(evt:any){
  console.log(evt.target.value,'evet');
  this.billFilter.status = evt.target.value;
  this.billFilterList();
}

billFilterList(){

  let localOrderList = this.orderListSource;
    if(this.billFilter.billId ){
    console.log('checking')
    localOrderList = localOrderList.filter((x:any)=>{
       return x.billid &&
             x.billid.toString().includes(this.billFilter.billId.toString());
    })

    this.orderlist = localOrderList;
  }

  if(this.billFilter.totalAmount){
    console.log('total',this.billFilter.totalAmount)
    localOrderList = localOrderList.filter((x:any)=>{
      return  x.totalamount.toString().includes(this.billFilter.totalAmount.toString()) ;
       console.log(x.totalamount.toString().includes(this.billFilter.totalAmount.toString()) );
    })
    this.orderlist = localOrderList;
  }  


  if(this.billFilter.status){
    console.log('status',this.billFilter.status);
    localOrderList = localOrderList.filter((x:any)=>{
      console.log(x.lifecyclestatus.toString() == this.billFilter.status.toString());
      return  (x.lifecyclestatus.toString() == this.billFilter.status.toString());
    })
    this.orderlist = localOrderList;
  }  


  if(!this.billFilter.billId  && !this.billFilter.totalAmount && !this.billFilter.status){ 
    this.orderlist = this.orderListSource;
  }

}

formatDate(date: Date) {
  return date.toISOString().substring(0, 10); // YYYY-MM-DD
}


TodayDate(){
  console.log('1');
  this.post.fromDate = this.formatDate(new Date());
  this.post.toDate = this.formatDate(new Date());
  this.changeDef.detectChanges();
   this.getOrderByDate();
  //this.getOrderReport(this.post.formDate,this.post.toDate);
}

  constructor(private query:QueryService,private changeDef:ChangeDetectorRef){

  }

  ngOnInit(): void {
    this.getOrderInit();  
  }


  getOrderByDate(){
    let fromDate = this.post.fromDate;
    let toDate =  this.post.toDate;
    let status = this.post.status;
    console.log(fromDate,toDate,'--fromDate,--toDate');
    this.getOrderReport(new Date(fromDate),new Date(toDate),status);
  }


  getOrderInit(){
    // let addMonth = new Date().setMonth(new Date().getMonth() -1); 
    this.getOrderReport(new Date(),new Date() , 'approved');
  }

  getOrderReport(fromDate:Date,toDate:Date,status:any){
    
   // let addMonth = new Date().setMonth(new Date().getMonth() - 1); 
    //console.log(new Date(addMonth),'add-month',new Date());
   // return;
    let convertFromDate = fromDate.toISOString().split('T')[0];
    let convertToDate = toDate.toISOString().split('T')[0];

    console.log(convertFromDate,convertToDate,'--convert From date');
    
    let getObject = {
      fromDate:convertFromDate,
      toDate:convertToDate,
      status : status
    }

    this.query.getBillForReport(getObject).subscribe({
      next:((res:any)=>{
        this.totalEarnings.totalAmount = res.totalAmount;
        this.totalEarnings.subTotal = res.subtotal;
        this.orderlist = res.data;
        this.orderListSource = res.data;
        this.orderTypeWise =  res.orderTypeWiseTotals;
        this.getBarChart();
      }),
      error:((err:any)=>{
      })      
    })
  }


  getBarChart(){

    // let localOrderList = this.orderlist.reduce((acc,curr)=>{
    //   if(!acc[curr.billingid]){
    //     acc[curr.billingid] = {
    //       price : curr.totalprice,
    //       date : curr.timedate
    //     } 
    //   }else{
    //     acc[curr.billingid].price +=curr.totalprice;
    //   }
    //   return acc
    // },{})
    // let valuesOfOrderList = Object.values(localOrderList);
    // console.log(valuesOfOrderList,'localOrderList--',);
    
  }
}
