import { Component,OnInit, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '@applayout/header.component';
import { QueryService } from '@appservices/query.service';
import { ReactiveFormsModule, FormBuilder, FormGroup, Form, Validators } from '@angular/forms';
import { StateService } from '@appservices/state.service';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from '@appservices/alert.service';


@Component({
  selector: 'app-menu-list',
  standalone: true,
  imports: [HeaderComponent,CommonModule,ReactiveFormsModule],
  providers:[BsModalService,AlertService],
  template: `
  <app-header></app-header>
  <div class="wrapper">
            <div class="right-side">
              <div class="sub-header">
                  <div class="tt">
                    <h2 class="mn-tt">Menu</h2>
                  </div>  
                  <div class="btn-bg">
                    <button type="button" class="btn btn-primary" (click)="openModal(menuTemplate);setmenuList('create',0);">+ Create menu</button> 
                  </div>           
              </div>
              <div class="cnt">
                <table class="table custom-table">
                    <thead>
                      <tr>                        
                        <th scope="col">Id</th>
                        <th scope="col">Category Id</th> 
                        <th scope="col">Menu Name</th>     
                        <th scope="col">Description</th>     
                        <th scope="col">Current Price</th>      
                         <th scope="col">Code</th>  
                        <th scope="col" style="width:200px" >Action</th>
                      </tr>
                    </thead>
                    <tbody>

                    @for(fs of menuList; track fs.menuId){
                      <tr>
                       
                          <td>{{fs.itemid}}</td>
                          <td>{{fs.categoryid}}</td>
                          <td>{{fs.itemname}}</td>
                          <td>{{fs.description	}}</td>
                          <td>{{fs.defaultprice}}</td>
                             <td>{{fs.code}}</td>
                          <td class="custom-btn">  
                            <button type="button" class="btn btn-primary" (click)="setmenuList('edit',fs.itemid);openModal(menuTemplate);">
                                <i class="pi pi-file-edit " ></i>
                            </button>
                            <button type="button" class="btn btn-danger" (click)="getConfirmMessage(fs.itemid)">
                                <i class="pi pi-trash " ></i>
                            </button>
                          </td>
                      </tr>
                    }
                      
                      
                    </tbody>
                  </table>
              </div>              
            </div>


    </div>

    
     
     <ng-template #menuTemplate>
       <div class="modal-header">
         <h4 class="modal-title pull-left">{{menuFormTitle}} menu</h4>
         <button type="button" class="btn-close close pull-right" aria-label="Close" (click)="menuModalRef?.hide();">
           <span aria-hidden="true" class="visually-hidden">&times;</span>
         </button>
       </div>
       <div class="modal-body">
          <form  [formGroup]="menuForm"  *ngIf="menuForm"> 

           
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="itemname" name="itemname" class="col-form-label">Menu Name</label>
                <input type="text" value="" class="form-control" formControlName="itemname" />
                <div *ngIf="menuForm.get('itemname')?.invalid && menuForm.get('itemname')?.touched">
                  <small class="text-danger">Menu name is required.</small>
                </div>
              </div>


              <div class="col-md-6">
                <label for="description" name="description" class="col-form-label">Description</label>
                <input type="text" value="" class="form-control" formControlName="description" />
                <div *ngIf="menuForm.get('description')?.invalid && menuForm.get('description')?.touched">
                  <small class="text-danger">description is required.</small>
                </div>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-4">
                <label for="defaultprice" name="defaultprice" class="col-form-label">Current Price</label>
                <input type="text" value="" class="form-control" formControlName="defaultprice" />
                <div *ngIf="menuForm.get('defaultprice')?.invalid && menuForm.get('defaultprice')?.touched">
                  <small class="text-danger">Price is required.</small>
                </div>
              </div>

              <div class="col-md-4">
                <label for="categoryid" name="categoryid" class="col-form-label">Category Id</label>
                <select formControlName="categoryid" >
                  @for(cs of categoriesList; track cs.categoryid){
                   <option [value]="cs.categoryid">{{cs.categoryname}}</option>
                  }
                  </select>                
                <div *ngIf="menuForm.get('categoryid')?.invalid && menuForm.get('categoryid')?.touched">
                  <small class="text-danger">category id required.</small>
                </div>
              </div>

              <div class="col-md-4">
                <label for="code" name="code" class="col-form-label">Code</label>
                <input type="text" value="" class="form-control" formControlName="code" />
                <div *ngIf="menuForm.get('code')?.invalid && menuForm.get('code')?.touched">
                  <small class="text-danger">code id required.</small>
                </div>
              </div>


            </div>

            
            </form>
       </div>
       <div class="modal-footer"  *ngIf="menuForm">
            <button type="submit" [disabled]="menuForm.invalid" class="btn btn-primary" (click)="onHandleSubmit()">Save</button>            
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" (click)="menuModalRef?.hide()">Close</button>
          </div>
     </ng-template>   
  `,
  styles: ``
})
export class MenuListComponent {

  menuList:any=[];  
  menuForm!:FormGroup;
  menuFormTitle:String ='Create';
  menuModalRef?: BsModalRef;
  categoriesList:any[]=[];
  initialMenuForm ={
      itemid:0,
      categoryid:1,
      itemname:'',         
      description:'',
	    defaultprice:'',
      qty:1,
      code:''
  }
  constructor(private alertService: AlertService,private modalService: BsModalService,private query:QueryService,private fb:FormBuilder,private cdref: ChangeDetectorRef,private stateService:StateService){

  }

  ngOnInit(): void {
    
    this.getmenuList();

    this.getCategoriesList();

    this.menuForm = this.fb.group({
	    itemid:[this.initialMenuForm.itemid],
      categoryid:[this.initialMenuForm.categoryid,[Validators.required,Validators.pattern(/^\d+$/)]],
      itemname:[this.initialMenuForm.itemname,Validators.required],         
      description:[this.initialMenuForm.description,Validators.required],
	    defaultprice: [this.initialMenuForm.defaultprice, [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)  ]],
      qty:[this.initialMenuForm.qty]  ,
      code:[this.initialMenuForm.code,Validators.required]
    })

   // this.menuForm.get('categoryid')?.setValue('2');
  }

  openModal(template: TemplateRef<void>) {
    if (!template) {
      console.error('TemplateRef is undefined');
      return;
    }
    this.menuModalRef = this.modalService.show(template);
  }


  getCategoriesList(){    
    this.stateService.setLoadingState(true);
   
    this.query.getCategories().subscribe({
      next:((res:any)=>{
        this.categoriesList = res.data;
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      complete: () => this.stateService.setLoadingState(false)
    })
    
  }
  

  getmenuList(){    
    this.stateService.setLoadingState(true);
   
    this.query.getMenus().subscribe({
      next:((res:any)=>{
        this.menuList = res.data;
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      complete: () => this.stateService.setLoadingState(false)
    })
    
  }

  
  getConfirmMessage(id:Number){
    this.alertService.showAlert('Confirmation !','Do you want to delete the menu',()=>{
      console.log('confirmed');
      this.deletemenuList(id);
    });
  }


  deletemenuList(id:Number){
    this.stateService.setLoadingState(true);
    this.query.deleteMenu(id).subscribe({
      next:((res:any)=>{
        console.log(res,'result');
        this.getmenuList();
        this.stateService.setLoadingState(false);
        this.alertService.showAlert('Alert !','menu has been deleted');
      }),
      error:((err:any)=>{
        console.log(err,'err');
        this.stateService.setLoadingState(false);
        this.alertService.showAlert('Error !',err.message);
      }),
      complete: (() => {
         this.stateService.setLoadingState(false);    
      })
    })
    
  }


  setmenuList(flag: string, inputId: number) {

    this.menuFormTitle = flag;
  
    if (flag === 'create') {
      this.menuForm.reset(this.initialMenuForm);
      console.log(this.menuForm);
    } else if (flag === 'edit') {
      const localmenuForm = this.menuList.filter((x: any) => x.itemid === inputId);
  
      if (localmenuForm && localmenuForm.length > 0) {
        this.menuForm.patchValue({
          itemid: localmenuForm[0].itemid,
          categoryid: localmenuForm[0].categoryid,
          itemname: localmenuForm[0].itemname,
          description: localmenuForm[0].description,
          defaultprice: localmenuForm[0].defaultprice,
          qty:localmenuForm[0].qty,
          code:localmenuForm[0].code
        });
      } else {
        console.error('menu data not found for id:', inputId);
      }
    }
    //this.openModal(menuTemplate);
  }

  onHandleSubmit() {
    this.stateService.setLoadingState(true);
    if (this.menuForm.valid) {      
      const outputParams = this.menuForm.value;
      console.log(outputParams, 'outputParams');

      const request$ = outputParams.itemid && outputParams.itemid !==0 ? this.query.updateMenu(outputParams) : this.query.addMenu(outputParams);
      request$.subscribe({
        next: (res: any) => {
          console.log(res, '--set-categories');
          this.menuModalRef?.hide();
          this.getmenuList(); // Refresh list
          this.stateService.setLoadingState(false);
           this.alertService.showAlert('Success!','menu has been created successfully');
        },
        error: (err: any) => {
          this.menuModalRef?.hide();
          this.stateService.setLoadingState(false);
          console.error(err, '--err-categories');
        },
        complete: () => {this.stateService.setLoadingState(false);}
      });
      
    }

  

  }
  
  
}
