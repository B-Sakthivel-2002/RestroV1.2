import { Component, ElementRef, input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { HeaderComponent } from '@applayout/header.component';
import { CommonModule } from '@angular/common';
import { QueryService } from '@appservices/query.service';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, Observable } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';
import { StateService } from '@appservices/state.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from '@appservices/alert.service';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StorageService } from '@appservices/storage.service';

@Component({
  selector: 'app-order',
  standalone: true,
  imports: [HeaderComponent,CommonModule,ReactiveFormsModule,FormsModule],
  providers:[BsModalService,AlertService],
  template: `
   <app-header></app-header>
   <div class="wrapper">        
        <div class="right-side">

          <div class="order-content">
              <div class="lft">

                <div class="sub-header spl">                    
                  
                    
                    <div class="tt">
                      <h4 class="sb-tt"> Customer name</h4> 
                  
                      <select class="form-select" aria-label="Default select example" (change)="onCustomerSelect($event)">
                          <option value="-1" selected>Select a customer</option>                        
                        @for(cs of customerList; track cs.customerid){
                          <option [value]="cs.customerid">{{cs.name}}</option>
                        }
                      </select>
                    </div>
            
<!-- 
                    <div class="tt">
                      <h4 class="sb-tt"> Waiter</h4> 
                      <select class="form-select" aria-label="Default select example" (change)="onWaiterSelect($event)">
                          <option value="-1" selected>Select a customer</option>
                          @for(wt of waiterList; track wt.waiterid){
                            <option [value]="wt.waiterid">{{wt.waitername}}</option>
                          }
                      </select>
                    </div> -->

                    <div class="tt">
                      <h4 class="sb-tt"> Type</h4>                    
                      <select class="form-select" aria-label="Default select example" disabled>   
                       
                          @for(ot of orderTypeList; track ot.ordertypeid )      {              
                           <option [value]="ot.ordertypeid" [selected]="ot.ordertypeid==this.typeId">{{ot.ordertypename}}</option>
                           }                                              
                      </select>
                    </div>

                    <div class="tt">
                      <h4 class="sb-tt"> Search</h4> 
                      <input type="text" value="" class="form-control"   [formControl]="inputSearchMenu"/>
                    </div>
                    
                    <!-- <div class="tt" style="margin-top: 26px;">
                      <button class="btn btn-danger"> Print Bill</button> 
                      <button class="btn btn-primary"> Ticket Notes</button> 
                      <button class="btn btn-primary"> Change Table</button> 
                      <button class="btn btn-danger"> Clear All</button> 
                    </div> -->
                </div>


                <div class="cnt-scrl">
                  <div class="mn-list-bg">
                    <!-- {{foodMenuList | json}} -->
                    @for(fd of foodMenuList; track fd.id; let customIndex = $index){
                      <div class="mn-list" [ngClass]="fd.flag ? 'active':''" (click)="getSubMenuList(fd.id);" [ngStyle]="{'background-color':colorList[customIndex],'color': colorList[customIndex] ? '#fff':'#000','border-color': colorList[customIndex]}" >
                        <h4>{{fd.name}}</h4>
                      </div>
                    }
                  </div>
                  <div class="mn-ls-vw-bg">
                    <div class="mn-ls-vw">
                       <!-- {{subMenuList | json}}  -->
                      @for(sb of subMenuList; track sb.itemid){                       
                        <div class="ls-vw" (click)="addOrderList(sb)">  
                           <i class="spl-icon pi pi-shopping-cart"></i> 
                          <h4> {{sb.name}}</h4>
                          <span><i class="icon pi pi-indian-rupee"></i>  {{sb.price}}</span>
                        </div>
                      }@empty {
                        <div>
                          No data found 
                        </div>
                      }
                    </div>
                  </div>
                </div>
                
                
              </div>
             
              <div class="rgt">
                <div class="container-bill" #customPrintOut  id="customPrintOut">
                  <div class="order-list grey-bg">  
                     <div class="ls">
                          <p class="text-left spl-bg">Type  : 
                     
                             <!-- @for(ot of orderTypeList; track ot.ordertypeid ){                               
                                <span *ngIf="ot.ordertypeid == typeId">{{ot.ordertypename}}</span>                             
                             } -->
                            </p>                          
                          <p class="spl-bg">{{tableName}} </p>                          
                      </div>
                  </div>

                  <div class="order-list spl-bg">  
                     <div class="ls hd">
                          <h2 class="text-left">Menu Name</h2>    
                          <p>Rate</p>                      
                          <p>Quantity</p>
                          <p>T.Price</p>
                      </div>
                  </div>

                  <div class="cnt-scrl">
                     
                        @for(ls of postBill.orders; track ls.orderid; let ind =$index;){
                         
                          <div class="order-list" [ngStyle]="{'background-color' : ls.orderid!=0 ? '#fff': '#fffad6'}" >   
                            <div class="ls spl" >
                            @if(ls.orderid!=0){
                              <h2> 
                                <input type="checkbox" [checked]="ls.flag"  class="check-box" [disabled]="true"/>
                                 <span>Order Id. {{ls.orderid}} 
                                  <b>{{ls.status | uppercase}}</b> </span>
                              </h2>
                            }@else{
                              <h2>                                
                                 <span>New Order</span>
                              </h2>
                            }
                              
                            </div>       
                                         
                            @for(bl of ls.orderdetail; track bl.orderdetailid; let ind= $index){                             
                              <div class="ls">
                                <h2><span>{{bl.name}}</span></h2>   
                                <p>({{bl.price}})</p> 
                                @if(ls.orderid!=0){                   
                                  <p>{{bl.qty}}</p>
                                }@else {                                  
                                  <p><span (click)="substractOrder(ind)" class="btn btn-danger btn-sm">-</span>{{bl.qty}} <span (click)="addOrderList(bl)"  class="btn btn-primary btn-sm">+</span></p>
                                }
                                <p>{{bl.sumofprice}}</p>
                              </div>
                            }       
                            
                          </div> 
                        }
                  </div>

                  <div class="price-tag">
                    <div class="ls">
                        <div class="pr-lft">
                          <h4 [ngClass]="postBill.discount ? 'show':'hide'">
                            <span>Discount</span>
                            <span class="spl">{{postBill.discount}}                             
                           </span>
                          </h4>
                          <h4>
                            <span>Tax</span>
                            <span class="spl">{{postBill.tax}}</span>
                          </h4>
                          <h4>
                            <span>Extra charges</span>
                            <span class="spl">{{postBill.extraAmount}}</span>

                          </h4>

                          <h4>
                            <span>Sub Total Amount</span>
                            <span class="spl"><b>{{postBill.subTotalAmount}}</b></span>
                          </h4>
                          <h4>
                            <span>Total amount</span>
                            <span class="spl">{{postBill.totalAmount}}</span>
                          </h4>
                        </div>   
                    </div>
                   
                  </div>

                  <div class="btn-bg">                    
                    <div class="row">
                      <div class="col-md-12">
                        <div class="comment-bg" *ngIf="inputCommentFlag">
                          <h4>Comment <i class="pi pi-times icon" (click)="inputCommentFlag = !inputCommentFlag"></i></h4>
                          <textarea [(ngModel)]="inputComment" class="form-control" name="comment"></textarea>
                        </div>
                        <div class="ds-btn-bg">
                          <!-- <select class="form-control" (change)="onDiscountSelect($event)" >
                            <option [value]="-1" selected>Select a discount</option>                         
                            @for(sd of discountList; track sd.discountId; let idx= $index){
                              <option [value]="idx">
                                {{ sd.discountname }}
                              </option>
                            }
                          </select> -->
                        
                        </div>
                        <!-- (click)="setNewBill()" -->
                        <button  class="btn btn-primary"  (click)="openModal(settleTemplate,'settle')"  [disabled]="!this.isSettle"> Settle</button>
                        <button  class="btn btn-primary" (click)="setNewOrder()" [disabled]="!this.isKOT" > KOT</button>
                        <button class="btn btn-primary" (click)="inputCommentFlag = !inputCommentFlag" [disabled]="!this.isKOT" ><i class="pi pi-align-left"></i></button>
                        <!-- <button  class="btn btn-primary">Payment</button> -->
                       
                        <button  class="btn btn-danger float-end" (click)="setPrintBill()" [disabled]="!this.isSettle"> 
                          <i class="pi pi-print"></i>                          
                           </button>
                         <button class="btn btn-danger float-end" [disabled]="!this.isKOT" (click)="setLocalOrderStorage()"> 
                          <i class="pi pi-save"></i>
                         </button>
                         <button (click)=" print()">print1</button>
                           <button class="btn btn-primary" (click)="openModal(discountTemplate,'discount')" [disabled]="!this.isSettle">%</button>
                    
                      </div>
                    </div>
                  </div>

                </div>
              </div>
          </div>

        </div>
    </div>

    	<ng-template #discountTemplate>
       <div class="modal-header">
         <h4 class="modal-title pull-left">Discount</h4>
         <button type="button" class="btn-close close pull-right" aria-label="Close" (click)="discountModalRef?.hide();">
           <span aria-hidden="true" class="visually-hidden">&times;</span>
         </button>
       </div>
       <div class="modal-body">
         <div class="row mb3">		 
			      <div class="col-md-6">
              <label for="floorname" name="floorname" class="col-form-label">Select discount</label>   
              <select class="form-control"  [(ngModel)]="selectDiscount.id" (change)="onChangeDiscountSelect($event)" >
                  <option [value]="-1" selected>Select a discount</option>                          
                  @for(sd of discountList; track sd.discountId; let idx= $index){
                    <option [value]="idx">
                      {{ sd.discountname }}
                    </option>
                  }
                </select> 
            </div>
            <div class="col-md-6">
              @if(selectDiscount.flag){
                 <input type="text"  [(ngModel)]="selectDiscount.value" class="form-control"  (keypress)="allowOnlyNumbers($event)" >
              }
            </div>
		      </div>
       </div>
       <div class="modal-footer" >
        <!-- {{localDiscount.id}} -->
            <button type="submit" [disabled]="!selectDiscount.id" class="btn btn-primary" (click)="onDiscountSelect(selectDiscount.id)">Save</button>            
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" (click)="discountModalRef?.hide()">Close</button> 
       </div>
     </ng-template>  

     <ng-template #settleTemplate>
       <div class="modal-header">
         <h4 class="modal-title pull-left">{{ isPrinted ? 'Update Settle' : 'Settle'}}</h4>
         <button type="button" class="btn-close close pull-right" aria-label="Close" (click)="settleModalRef?.hide();">
           <span aria-hidden="true" class="visually-hidden">&times;</span>
         </button>
       </div>
       <div class="modal-body">
			<div class="row mb3">		 
			  <div class="col-md-6">
				<label class="col-form-label">Payment Status</label>   
				<select class="form-select" [(ngModel)]="postBill.status"  (ngModelChange)="onStatusChange($event)">
          <option value="" default>Select status</option>
					<option value="paid">Paid</option>
					<option value="unpaid">Unpaid</option>					
				</select>
				</div>
				<div class="col-md-6">
					<label class="col-form-label">Payment Mode</label>   
					<select  class="form-select" [(ngModel)]="postBill.paymentmode" [disabled]="postBill.status!=='paid' ? true : false ">
            <option value='' default>Select payment</option>
						<option value="cash">Cash</option>
						<option value="upi">UPI</option>					
						<option value="card">Card</option>					
						<option value="split">Split</option>					
					</select>		
				</div>
		    </div>
			<div class="row mb3">		 
			  <div class="col-md-6">
			  	<label class="col-form-label">Paid Amount</label>   
				  <input type="text"  class="form-control" [(ngModel)]="postBill.paidamount" [disabled]="postBill.status!=='paid' ? true : false " >
				</div>
				<div class="col-md-6">
					<label class="col-form-label">Notes </label>   
					<textarea class="form-control"  class="form-control" [(ngModel)]="postBill.notes" [disabled]="postBill.status == 'unpaid'" 	>
					</textarea>
				</div>
		    </div>
			<div class="row mb3">		 
			  <div class="col-md-6">
					<label class="col-form-label">Is It Complementary ?</label>   
					<div>
					  <label>
						<input type="radio" name="iscomplementary" [value]="true" [(ngModel)]="postBill.iscomplementary" [disabled]="postBill.status == 'paid'" (click)="postBill.status='unpaid';postBill.paymentmode='';postBill.paidamount=''"> Yes
					  </label>
					  <label style="margin-left: 10px;">
						<input type="radio" name="iscomplementary" [value]="false"  [(ngModel)]="postBill.iscomplementary" [disabled]="postBill.status == 'paid'" > No
					  </label>
					</div>
				</div>
				<div class="col-md-6">
					<label class="col-form-label">Complementary Reason</label>   
					<textarea class="form-control"  class="form-control" [(ngModel)]="postBill.complementaryreason" [disabled]="!postBill.iscomplementary"	>
					</textarea>
				</div>
		    </div>
       </div>
       <div class="modal-footer" >
        <!-- {{localDiscount.id}} -->
         <!-- {{postBill.isComplementary }} {{postBill.status}}
         {{ (postBill.status == 'paid' && !(postBill.paidamount && postBill.paymentmode))}} -->
         <button
            type="submit"
            class="btn btn-primary"
            [disabled]="
              (postBill.status == 'paid' && !(postBill.paidamount && postBill.paymentmode)) ||
              (postBill.status == 'unpaid' && !(postBill.iscomplementary)) ||
              (postBill.status == '')
            "
            (click)=" isPrinted ? updateNewBill(updateBillId) : setNewBill();settleModalRef?.hide();">
            Save
          </button>
         
           
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" (click)="settleModalRef?.hide()">Close</button> 
       </div>
     </ng-template>  
  `,
  styles: ``
})
export class OrderComponent implements OnInit {


  constructor(private router:Router, private modalService: BsModalService,private orderLocalStorage:StorageService,private alertService:AlertService,private stateService:StateService,private query:QueryService,private activeRoute: ActivatedRoute,private changeDetectRef:ChangeDetectorRef){

  }

  tableId!:Number;
  floorId!:Number;
  //tableid!:Number;
  typeId!:Number;
  tableName!:String;
  customerList:any =[];
  selectedcustomerid:any =0;
  selectedwaiterid:any=0;
  selectedordertypeid:any=1;
  waiterList:any=[];
  foodMenuList:any=[];
  subMenuList:any=[];
  inputTax:any=5;
  inputDiscount:any =[];
  discountList:any =[];
  extraList:any=[];
  taxList:any =[];
  orderTypeList:any =[];
  isPrinted:boolean = false;
  updateBillId:any = -1;
  isSettle:boolean = false;
  isKOT:boolean= false;
  inputSearchMenu = new FormControl('');
  inputComment:any ='';
  inputCommentFlag:boolean = false;
  selectDiscount:any={
    id:-1,
    value:0,
    flag:'',
  }
  @ViewChild('settleTemplate') settleTemplate!: TemplateRef<any>;

  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }

  discountModalRef?: BsModalRef;
  settleModalRef?:BsModalRef;

  private defaultPostBill = {
  orders: [],
  lifecycleStatus:'printed',
  totalAmount: 0,
  billAmount: 0,
  tax: 0,
  subTotalAmount: 0,
  taxList: [],
  discountList: [],
  discountid:[],
  extraList: [],
  extraAmount: 0,
  discount: 0,
  discountType: '',
  discountIndex: 0,
  discountFlag: false,
  notes: '',
  paidamount: '',
  paymentmode: '',
  status: '',
  iscomplementary: false,
  complementaryreason: ''
};

postBill:any ={...this.defaultPostBill};

  

  colorList: string[] = [
    '#037171',
    '#ee3c3f',
    '#7209b7',
    '#4361ee',
    '#f72585', 
    '#001845',
    '#231942',
    '#bc00dd',
    '#0582ca',
    '#5c6b73',
    '#216869',
    '#001c55',
  ];

  foodMenuSearchList:any =[];

  @ViewChild('customPrintOut') customPrintOut !:ElementRef;
  
    // openModal(template: TemplateRef<void>) {
    //   if (!template) {
    //     console.error('TemplateRef is undefined');
    //     return;
    //   }
    //   this.discountModalRef = this.modalService.show(template);
    // }

  openModal(template: TemplateRef<void>, type: 'discount' | 'settle') {
        if (!template) {
          console.error('TemplateRef is undefined');
          return;
        }

        const modalRef = this.modalService.show(template);

        if (type === 'discount') {
          this.discountModalRef = modalRef;
        } else if(type === 'settle') {
          this.settleModalRef = modalRef;
        }
  }

  onStatusChange(newStatus: string) {
    console.log('Status changed:', newStatus);

    if (newStatus === 'paid') {
      this.postBill.lifecycleStatus = 'finalized';
      this.postBill.iscomplementary =  false;
      this.postBill.complementaryreason= '';
    //  this.postBill.paidamount = this.postBill.billAmount; // auto set full payment
    }

    if (newStatus === 'unpaid') {
      this.postBill.lifecycleStatus = 'complementary';
      this.postBill.iscomplementary =  true;
      this.postBill.complementaryreason= '';
     // this.postBill.paidamount = 0;
    }

  }
  

  print() {
  const printContents = this.customPrintOut.nativeElement.innerHTML;
  const printWindow = window.open('', '', 'width=400,height=600');

  if (printWindow) {
    const doc = printWindow.document;

    // Create HTML elements safely
    const html = doc.createElement('html');
    const head = doc.createElement('head');
    const body = doc.createElement('body');

    // Add styles
    const style = doc.createElement('style');
    style.textContent = `
      body { font-family: Arial, sans-serif; padding: 0px; font-size: 10px; }
      h2 { color: #333; }
      button,select { display: none; }  
     .order-list {
  display: flex;
  flex-direction: column;
  background: #fff;
}

 .order-list .ls {
display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 5px 0px;
  font-size: 13px;
}

 .order-list .ls h2{
 width:30%;
 font-size: 14px;
  margin: 0;
  font-weight:normal;
  }

 .order-list .ls .text-left {
  text-align: left;
}
 .order-list .ls p {
  margin-bottom: 0px;
  width: 20%;
  text-align: right;
  font-weight: normal;
  margin-top:0;
}

 .order-list .ls p.spl-bg {
  width: auto;
}
 .order-list .ls p {
  margin-bottom: 0px;
  width: 20%;
  text-align: right;
  font-weight: normal;
}
  .price-tag .ls .pr-lft h4{
	text-align:right;
font-size:14px;
border-top:1px solid #ccc;
margin:0px;
padding:10px 0px;
font-weight:normal;
}
.price-tag .ls .pr-lft h4.show{
display:block;
}
.price-tag .ls .pr-lft h4.hide{
display:none;
}
.price-tag .ls .pr-lft h4 span{
margin-left:10px;
}

 .order-list .ls.hd{
 border-top:1px solid #ccc;
 padding:7px 0px;
 border-bottom:1px solid #ccc;
  }

.price-tag .ls .pr-lft h4 span.spl{
width: 150px;
  display: inline-block;
  font-weight:bold;
  }
  .order-list .ls.spl{
  display:none;
  }
    `;
    head.appendChild(style);

    // Set print contents
    body.innerHTML = printContents;

    // Auto-print and close after printing
    body.onload = () => {
     // console.log('onloading');
      printWindow?.print();
      printWindow?.close();
    };

    html.appendChild(head);
    html.appendChild(body);

    doc.documentElement.replaceWith(html); // replaces current empty <html> with the new one
  }
}


  ngOnInit(): void {
    this.getParameterValue();
    this.getCustomerList();
    //this.getWaiterList();
    this.getFoodMenuList();
    this.getDiscountList();
    this.getTaxList();
    this.getorderTypeList();
    this.searchMenuList();
  }


  getLocalOrderStorage(){

    let inputParam = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId
    }
    console.log('getLocalStorage');
    this.orderLocalStorage.getOrderDetail(inputParam).subscribe({
      //  next:((res:any)=>{
      //   this.orderTypeList = res.data;
      //   console.log(res,'res'); 
      // }),
      // error:((err:any)=>{        
      // }),

      next:((res:any)=>{
        console.log(res,'-----get--local--stoorage');
        // if(res.length !=0 && res.orderDetail.length !=0){
        //   this.postBill.orders.push(res.orderDetail);
        //   this.calculatetotalprice();
        //   this.isSettle = false;
        //   this.isKOT = true;
        //  // this.calculatetotalprice();   
        // }
       console.log(res,'getLocalStorage');
      }),
      error:((err:any)=>{
        
      })

    })
  }



 setLocalOrderStorage(){
    let orderDetail = this.postBill.orders[this.postBill.orders.length-1];
    if (orderDetail.orderid) return;
    let inputParam = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId,
      orderDetail:orderDetail
    }
    this.orderLocalStorage.setOrderDetail(inputParam,true).subscribe({
      next:((res:any)=>{
        console.log(res,'setLocalStorage');
      }),
      error:((err:any)=>{        
      })
    })
  }
  

  onCustomerSelect(event:any){
    let inputValue = event.target.value;
    this.selectedcustomerid = inputValue;
   // this.postBill.
    console.log(inputValue);
  }

  // onWaiterSelect(event:any){
  //   let inputValue = event.target.value;
  //   this.selectedwaiterid = inputValue;
  // }

  onOrderTypeSelect(event:any){
    let inputValue = event.target.value;
    this.selectedordertypeid = inputValue;
  }

  onSelectedBill(ind:any){

    if (!this.postBill.orders[ind] || this.postBill.orders[ind].orderid === 0) {
      return;
    }
    this.postBill.orders[ind].flag = !this.postBill.orders[ind].flag ;    
  }

  onOrderDecrement(ind:any){
    

  }


  getParameterValue(){
    this.activeRoute.paramMap.subscribe((params:any)=>{
      this.tableId = params?.get('tableId');
      this.floorId = params?.get('floorId');
      this.typeId = params?.get('typeId');
      this.tableName = params?.get('tableName');
      this.getOrderByTable(this.tableId,this.typeId);
        this.getLocalOrderStorage();
    })
  }

  getorderTypeList(){    
    //this.stateService.setLoadingState(true);
   
    this.query.getOrderTypes().subscribe({
      next:((res:any)=>{
        this.orderTypeList = res.data;
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      //complete: () => this.stateService.setLoadingState(false)
    })
    
  }


  getCustomerList(){
    this.query.getCustomers().subscribe({
      next:((res:any)=>{
        console.log(res,'res');
        this.customerList = res.data;
        if(res.status=='success'){         
          console.log(this.customerList);
        }
      }),
      error:((err:any)=>{
      })
    })
  }

  // getWaiterList(){
  //   this.query.getWaiters().subscribe({
  //     next:((res:any)=>{
  //       this.waiterList = res.data;
  //       if(res.status=='success'){          
  //         console.log(this.waiterList);
  //       }
  //     }),
  //     error:((err:any)=>{
  //     })
  //   })
  // }


  

  getFoodMenuList(){
    this.query.getFoodMenuList().subscribe({
      next:((res:any)=>{
        console.log(res,'res111');
        this.foodMenuList = res.menu;   
        this.foodMenuSearchList = this.foodMenuList.map((x:any)=>x.orderdetail).flat();
        this.getSubMenuList(this.foodMenuList[0].id);
      }),
      error:((err:any)=>{})
    })
  }

  getDiscountList(){
    this.query.getDiscounts().subscribe({
      next:((res:any)=>{
        this.discountList = res.data;
        console.log(res,'get-discount-list');
      }),
      error:((err:any)=>{

      })
    })
  }


  getExtrasList(){
    this.query.getDiscounts().subscribe({
      next:((res:any)=>{
        this.extraList = res.data;
        console.log(res,'get-discount-list');
      }),
      error:((err:any)=>{

      })
    })
  }
  async getTaxList(){
    this.query.getTax().subscribe({
      next:(async (res:any)=>{
        console.log(res,'getTax');
        this.taxList =  res.data;
        this.postBill.taxList = this.taxList;
        this.calculatetotalprice();
      }),
      error:((err:any)=>{ })
    })
  }

  async getExtraChargesList(){
    this.query.getExtraCharges().subscribe({
      next:(async (res:any)=>{
        console.log(res,'getExtra');
        this.extraList =  res.data;
      }),
      error:((err:any)=>{ })
    })
  }

  onChangeDiscountSelect(event:any){
    const selectedValue = event.target.value;  
      if( this.discountList[selectedValue].discountname=='customize'){
          this.selectDiscount.flag = true;
      }else{
         this.selectDiscount.flag = false;
      }
  }

  onDiscountSelect(inputId: any): void {
    //const selectedValue = event.target.value;  
    const selectedValue = inputId;
   
   if(selectedValue!=-1){
    this.postBill.discountFlag = true;
   // this.postBill.discount = this.discountList[selectedValue].discountrate;    
    this.postBill.discountType = this.discountList[selectedValue].discounttype;
    this.postBill.discountIndex = Number(selectedValue);    
    this.postBill.discountid =[this.discountList[selectedValue].discountid];
    this.discountModalRef?.hide()
   }else{
    this.postBill.discountFlag = false;
    this.postBill.discount =0;
    this.postBill.discountType ='';
    this.postBill.discountIndex = -1;
    this.postBill.discountid = [];
    this.selectDiscount.value = 0;
   // this.postBill.discount = 0;
   }
   this.calculatetotalprice();    
  }

  async addOrderList(InputObject: any) {
    console.log(InputObject, 'Object');
    let orderIndex = this.postBill.orders.findIndex((x: { orderid: number }) => x.orderid === 0);
    if (orderIndex !== -1) {
        let order = this.postBill.orders[orderIndex];
        let itemIndex = order.orderdetail.findIndex((x: { itemid: number }) => x.itemid === InputObject.itemid);      
        if(itemIndex !== -1){         
          this.postBill.orders[orderIndex].orderdetail[itemIndex].qty += 1;
          //this.postBill.orders[orderIndex].orderdetails[itemIndex].sumofprice += InputObject.price;
          this.postBill.orders[orderIndex].orderdetail[itemIndex].sumofprice = 
    parseFloat((this.postBill.orders[orderIndex].orderdetail[itemIndex].sumofprice + InputObject.price).toFixed(2));

        }else{          
          InputObject.qty = InputObject.qty ? InputObject.qty : 1;
          InputObject.sumofprice = InputObject.sumofprice ? InputObject.sumofprice :  InputObject.price;
          this.postBill.orders[orderIndex].orderdetail.push({...InputObject});
        }        
        order.totalprice =  order.totalprice + InputObject.price;
    } else {
        InputObject.qty = InputObject.qty ? InputObject.qty : 1;
        InputObject.sumofprice = InputObject.sumofprice ? InputObject.sumofprice :  InputObject.price;
        this.postBill.orders.push({
            orderid: 0,
            waiterid: this.selectedwaiterid,          
            tableid: this.tableId,           
            timedate: new Date().toISOString(),
            customerid: this.selectedcustomerid,
            bookingid: 0,
            ordertypeid:this.typeId,
            orderdetail: [{...InputObject}],
            totalprice: InputObject.price ,
            status: '',
            billingid: 0,
            printf:false,            
            comments:this.inputComment,
        });
    }
    this.calculatetotalprice();
    this.isSettle = false;
    this.isKOT = true;
}

substractOrder(ind:any){
  let orderIndex = this.postBill.orders.findIndex((x: { orderid: number }) => x.orderid === 0);   
  if (orderIndex !== -1) {
 let localPrice = this.postBill.orders[orderIndex].orderdetail[ind].price;	
    if(this.postBill.orders[orderIndex].orderdetail[ind].qty !=1){
        this.postBill.orders[orderIndex].orderdetail[ind].qty -= 1;        
        this.postBill.orders[orderIndex].orderdetail[ind].sumofprice = 
        parseFloat((this.postBill.orders[orderIndex].orderdetail[ind].sumofprice - localPrice).toFixed(2));    	
        this.postBill.orders[orderIndex].totalprice = parseFloat((this.postBill.orders[orderIndex].totalprice - localPrice).toFixed(2)); 
    }else{
        this.postBill.orders[orderIndex].orderdetail.splice(ind,1);
        this.postBill.orders[orderIndex].totalprice = parseFloat((this.postBill.orders[orderIndex].totalprice - localPrice).toFixed(2)); 
         console.log(this.postBill.orders[orderIndex].orderdetail.length,'---len');
         if(this.postBill.orders[orderIndex].orderdetail.length==0){
              this.postBill.orders.splice(orderIndex,1);
              this.isSettle = true;
              this.isKOT = false;
          }	
    }
    this.calculatetotalprice();
  }
}


  setNewOrder(){
    let orderDetail = this.postBill.orders[this.postBill.orders.length-1];
    let inputParamStorage = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId,
    }

    if (orderDetail.orderid) return;

    orderDetail.customerid = this.selectedcustomerid ?  this.selectedcustomerid : 0;
    orderDetail.waiterid = this.selectedwaiterid ? this.selectedwaiterid:0;
    orderDetail.comments = this.inputComment;
    console.log(orderDetail,'set-new-orderDetail');    
    this.query.setOrderList(orderDetail).subscribe({
      next:((res:any)=>{
        if(res.status =='Success'){
          this.orderLocalStorage.setOrderDetail(inputParamStorage,false);
          this.getOrderByTable(this.tableId,this.typeId);
          this.changeDetectRef.detectChanges();  
          this.inputComment ='';
          this.alertService.showAlert('Success','KOT has been sent successfully');           
        }else{
           this.inputComment ='';
           this.alertService.showAlert('Error !','KOT has not been sent. Kindly check and resend.');
          //this.isKOT = false;
          //this.isSettle = false;
        }
        console.log(res,'result');
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message)
        console.log(err,'set New Order ')
      })

    })
  }
  //Cash / UPI / Card / Split

  setPrintBill(){
      this.postBill.lifecycleStatus = 'printed';
      this.postBill.iscomplementary =  false;
      this.postBill.complementaryreason= '';
      this.postBill.status ='unpaid';
      this.postBill.paidamount=null;
      this.postBill.notes=null;
      this.setNewBill();
  }

  async setNewBill(lifeStatus?: any){

      //taxList :this.postBill.taxList,
      // discountList:this.postBill.discountList,
      //extraList:this.postBill.extraList

    // if(lifeStatus=='Printed'){
    //   this.postBill.lifecycleStatus = 'Printed';
    //   this.postBill.status ='unpaid';
    // }

    console.log(this.postBill.discountid,'this.postBill.discountid');
    // this.postBill.status+
    let createBillObj = {
      billId: 0,
      lifecycleStatus: this.postBill.lifecycleStatus,
      dateTime: new Date().toISOString(),
      customerid: this.selectedcustomerid,
      phone: '',
      address: '',
      billname: '',
      gstin: '',
      comments: '',
      totalamount: this.postBill.totalAmount ,
      billamount: this.postBill.billAmount,
      tax: this.postBill.tax,
      extraamount: this.postBill.extraAmount,
      discount: this.postBill.discount,
      discountid:this.postBill.discountid,      
      orderids: [],
      taxid :[],
      extraid:[],
      subtotal:this.postBill.subTotalAmount,      
      paidamount:this.postBill.paidamount ? this.postBill.paidamount : null,
      paymentmode:this.postBill.paymentmode ? this.postBill.paymentmode : null,
      status:this.postBill.status,
	    notes:this.postBill.notes,
      iscomplementary:this.postBill.iscomplementary,
      complementaryreason:this.postBill.complementaryreason	    
    }

    console.log(this.postBill.orders,'this.postBill.orders');

    createBillObj.orderids = this.postBill.orders.filter((x: any) => x.flag).map((x: any) => x.orderid);
    createBillObj.taxid = this.postBill.taxList.map((x:any)=>x.taxid);
    //createBillObj.extraid = this.postBill.taxList.map((x:any)=>x.taxid);


    console.log(this.postBill.orders,createBillObj.orderids,createBillObj,'createBillObj.orderids');
     
    //return;
    //return;//
    this.query.setBillList(createBillObj).subscribe({
      next:(async(res:any)=>{
        console.log(res,'result of bill list')

        if(res.status=='Success'){
          await this.resetPostBill();
          //this.getOrderByTable(this.tableId,this.typeId);
          this.router.navigate(['/dinein']);
          this.alertService.showAlert('Success','Bill has been created successfully');
        }else{
          this.alertService.showAlert('Error','Bill has not created Please try again.');
        }
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message);
      })
    })
  }

  async updateNewBill(inputBillId: any){

    let updateBillObj = {
      billId: inputBillId,
      lifecycleStatus: this.postBill.lifecycleStatus,
      paidamount:this.postBill.paidamount ? this.postBill.paidamount : null,
      paymentmode:this.postBill.paymentmode ? this.postBill.paymentmode : null,
      status:this.postBill.status,
	    notes:this.postBill.notes,
      iscomplementary:this.postBill.iscomplementary,
      complementaryreason:this.postBill.complementaryreason	,
      orderids:[]   
    }

     updateBillObj.orderids = this.postBill.orders.filter((x: any) => x.flag).map((x: any) => x.orderid);
   
    this.query.updateBillList(updateBillObj).subscribe({
      next:(async(res:any)=>{
	  
        console.log(res,'result of bill list')
        if(res.status=='Success'){
          await this.resetPostBill();
          this.router.navigate(['/dashboard']);
         // this.getOrderByTable(this.tableId,this.typeId);
          this.alertService.showAlert('Success','Bill has been updated successfully');
        }else{
          this.alertService.showAlert('Error','Bill has not updated Please try again.');
        }
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message);
      })
    })
  }

  searchMenuList(){
    this.inputSearchMenu.valueChanges.pipe(debounceTime(100)).subscribe((x:any)=>{
      this.getSubMenuListBySearch(this.inputSearchMenu);
    })
  }

  resetPostBill() {
    this.postBill = { ...this.defaultPostBill };
    // this.postBill.orders=[];
    // this.postBill.totalAmount =0;
    // this.postBill.billAmount =0;
    // this.postBill.subTotalAmount =0;
    // this.postBill.tax=0;
    this.selectDiscount.value =0;
    this.selectDiscount.id =-1;
    this.selectDiscount.flag = false;
  }

  async getOrderByTable(id:any,typeId:Number){
    this.stateService.setLoadingState(true);
    this.postBill.orders =[];

    let localGetOrder ;

    if(typeId == 1){
      localGetOrder =  this.query.getOrderByTableId(id);      
    }else{
      localGetOrder =  this.query.getOrderByType(typeId);
    }

    localGetOrder.subscribe({
      next:((res:any)=>{

        if(res.status=='Success'){
          console.log(res,'get-order-by-table--')
          this.postBill.orders = res.data.map((x:any)=>{
            return {...x,flag:true}
          });


           this.postBill.orders = res.data.map((x:any)=>{
              if(x.status=='printed'){
                this.isPrinted =  true;
                this.updateBillId = x.billingid;
              }
              return {...x,flag:true}
          });

          console.log(this.postBill.orders)
          this.isSettle = true;
          this.isKOT = false;  
          this.calculatetotalprice();  
          if(this.isPrinted)        {
            this.openModal(this.settleTemplate,'settle')
          }
          this.changeDetectRef.detectChanges();
                
        }else{

        }
        
        this.stateService.setLoadingState(false);
        console.log(res,'getOrderBy Table ')
      }),
      error:((err:any)=>{
        this.stateService.setLoadingState(false);
      })

    })
     
  }

  async calculatetotalprice() {  
    console.log(this.postBill.orders);

    if (!Array.isArray(this.postBill.orders)) {
      console.error("postBill.orders is not an array!");
    }

    let localtotalprice = this.postBill.orders.reduce((sum: number, order: any) => {
      let price = Number(order.totalprice) || 0; // Ensure it's a valid number
      console.log(sum, price, 'totalprice');
      return sum + price;
    }, 0);
    // Round to 2 decimal places
   
    this.postBill.subTotalAmount = parseFloat(localtotalprice.toFixed(2));

     if (this.taxList.length && localtotalprice) {
      let localTaxAmount =0;
      await this.taxList.forEach((x: any) => {       
        const inRange = x.taxrangestatus ? (x.taxfrom <= localtotalprice && x.taxto >= localtotalprice) : true;
        if (!inRange) return;
        let taxAmount = 0;
        if (x.taxtype === 'percentage') {
          taxAmount = (localtotalprice * x.taxrate) / 100;
        } else if (x.taxtype === 'flat') {
          taxAmount = x.taxrate;
        }
        if(taxAmount){
         localtotalprice += Number(taxAmount) || 0;
         localTaxAmount += Number(taxAmount) || 0;
        }
      });
       this.postBill.tax =  parseFloat(localTaxAmount.toFixed(2));
    }


    if( this.postBill.discountFlag){
      //let localDiscount.valueAmount =0;
      let discountObject = await this.discountList[this.postBill.discountIndex]; 

      console.log(discountObject,'discountObject');

      if(discountObject.discountname=='customize'){
              this.postBill.discount =  Number(this.selectDiscount.value).toFixed(2) || 0 ;
              this.postBill.discountList = discountObject;  
              localtotalprice -= Number(this.selectDiscount.value)|| 0;
      }else{
          let discountRangeStatus = discountObject.discountrangestatus ?  (discountObject.discountfrom <= localtotalprice && discountObject.discountto >= localtotalprice) : true;
         
          if (discountRangeStatus) {
              let discountAmount =0;
                if(discountObject.discounttype=='percentage'){
                      discountAmount = ((localtotalprice * discountObject.discountrate) /100 );                       
                }else if(discountObject.discounttype =='flat'){
                        discountAmount = discountObject.discountrate;
                }
              localtotalprice -= Number(discountAmount)|| 0;
              this.postBill.discount =  Number(discountAmount).toFixed(2) || 0 ;
              this.postBill.discountList = discountObject;
          } 
      }      
    }
    /*extralist*/
  
    if (this.extraList.length && localtotalprice) {
      let localextraAmount =0;
      await this.extraList.forEach((x: any) => {  
          if(this.typeId==x.extratypeid){
              const inRange = x.extrarangestatus ? (x.extrafrom <= localtotalprice && x.extrato >= localtotalprice) : true;
              if (!inRange) return;
              let extraAmount = 0;              
              if (x.extratype === 'percentage') {
                extraAmount = (localtotalprice * x.extrarate) / 100;
              } else if (x.extratype === 'flat') {
                extraAmount = x.extrarate;
              }
              if(extraAmount){
              localtotalprice += Number(extraAmount) || 0;
              localextraAmount += Number(extraAmount) || 0;
              }            
          }
        });
    
        this.postBill.extraAmount =  parseFloat(localextraAmount.toFixed(2));

    }


    this.postBill.taxList =this.taxList;
    this.postBill.totalAmount = parseFloat(localtotalprice.toFixed(2));
    this.postBill.billAmount = parseFloat(localtotalprice.toFixed(2));
    
  }


  async removeOrderList(Obj:any){
    this.postBill.orders[0].items.findIndex((x:any)=>x.itemID==Obj.id);
  }


  getSubMenuList(id:Number){

    console.log(id,'submenu-list',this.foodMenuList);
    let getFoodMenuList:any = {};    
    
    const index = this.foodMenuList.findIndex((x: any) => x.id === id);
    getFoodMenuList = index !== -1 ? { data: this.foodMenuList[index], index } : null; 
    
    this.foodMenuList.filter((x:any)=>x.flag = false);    
    this.foodMenuList[getFoodMenuList.index].flag = true;
    this.subMenuList = getFoodMenuList.data.orderdetail;
    //this.foodMenuList
  }


  getSubMenuListBySearch(searchText:any){    
    console.log(searchText,'searchText');
    let inputSearchText =  searchText.value.toLowerCase();
    console.log(inputSearchText);
    let searchMenuList = this.foodMenuSearchList.filter((y:any)=>{
     if(y.name.toLowerCase().includes(inputSearchText) || y.code?.includes(inputSearchText)){
      return y;
     }
    });

     this.subMenuList = searchMenuList;
    // if(searchMenuList.length !=0){
     
    // }    
    console.log(searchMenuList,inputSearchText)
    console.log(searchMenuList,'allF');


  }



}
