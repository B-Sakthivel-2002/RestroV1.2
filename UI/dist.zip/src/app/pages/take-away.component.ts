import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderComponent } from '@applayout/header.component';
import { QueryService } from '@appservices/query.service';

@Component({
  selector: 'app-take-away',
  standalone: true,
  imports: [HeaderComponent,CommonModule],
  template: `
    <app-header></app-header>
    <div class="wrapper">
      <div class="right-side">
         <div class="wrapper">
            <div class="right-side">
              <div class="sub-header">
                  <div class="tt">
                    <h2 class="mn-tt">Take away</h2>
                  </div>  
                  <div class="btn-bg">
                    <button type="button" class="btn btn-primary" (click)="onHandleTakeAway()">+ Create Order</button> 
                  </div>           
              </div>
              <div class="cnt">
                <table class="table custom-table">
                    <thead>
                      <tr>          
                        <th scope="col">Order Id</th>
                        <th scope="col">Bill Id</th>
                        <th scope="col">Order Number</th>                
                        <th scope="col">Total Price</th>
                        <th scope="col">Order Type</th>                
                        <th scope="col">Date & Time </th>
                        <th scope="col" >Status</th>                        
                        <th scope="col" style="width:200px" >Action</th>
                      </tr>
                    </thead>
                    <tbody>

                      @for(bl of orderList; track bl.id){
                      <tr>
                        <td>{{bl.orderid}}</td>
                        <td>{{bl.billingid}}</td>
                        <td>{{bl.ordernumber}}</td>                    
                        <td>{{bl.totalprice}}</td>
                       <!-- <td>{{bl.ordertypeid}}</td>-->
                        <td>{{bl.ordertype}}</td>
                        <td>{{bl.timedate | date: 'dd-MM-yyyy'}}</td>
                        <td><span [ngClass]="bl.status=='submitted' ? 'bl-hgt' : bl.status=='approved' ? 'gr-hgt' : 'rd-hgt'">
                             {{bl.status=='submitted' ? 'In Progress' : bl.status=='approved' ? 'Completed' : 'Cancelled'}}
                          </span></td>
                        <td class="custom-btn" >    

                          @if(bl.status=='submitted'){
                            <button type="button" class="btn btn-primary">
                                <i class="pi pi-file-edit " ></i>
                            </button>
                            <button type="button" class="btn btn-danger">
                                <i class="pi pi-trash " ></i>
                            </button>
                          }

                        </td>
                      </tr>
                     }
                        @empty {
                        <tr><td colspan="9" class="text-center">No data found</td></tr>
                      }                      
                    </tbody>
                  </table>
              </div>              
            </div>
        </div>
      </div>
    </div>
  `,
  styles: ``
})
export class TakeAwayComponent implements OnInit {

    orderList:Array<any>=[];
    constructor(private query:QueryService,private router:Router){

    }

    ngOnInit(): void {
      this.getOrderInit();  
    }

     getOrderInit(){
      let addMonth = new Date().setMonth(new Date().getMonth() -1); 
      this.getOrderReport(new Date(addMonth),new Date() , 'Approved');
    }

  getOrderReport(fromDate:Date,toDate:Date,status:any){    
   // let addMonth = new Date().setMonth(new Date().getMonth() - 1); 
    //console.log(new Date(addMonth),'add-month',new Date());
   // return;
    let convertFromDate = fromDate.toISOString().split('T')[0];
    let convertToDate = toDate.toDateString().split('T')[0];
    
    let getObject = {
      fromDate:convertFromDate,
      toDate:convertToDate,
      status : status
    }

    this.query.getOrderByType(2).subscribe({
      next:((res:any)=>{
        this.orderList = res.data;
     //   this.getBarChart();
      }),
      error:((err:any)=>{

      })      
    })
  }


  onHandleTakeAway(){
    this.router.navigate(['/order/0/0/'+2+'/'+'']);
  }


}
