import { Routes } from '@angular/router';
import { RoleGuard } from './core/guards/role.guard';
import { authGuard,afterLogged } from './core/guards/auth.guard';
import { ProductListComponent } from './pages/product-list.component';
export const routes: Routes = [
   {
    path:'',
    loadComponent:()=>import('./pages/login.component').then(m=>m.LoginComponent),
     canActivate:[authGuard]
   },
   {
    path:'dashboard',
    loadComponent:()=>import('./pages/dashboard.component').then(m=>m.DashboardComponent),
    canActivate: [RoleGuard],
    data:{dataRoles:['Admin','Captain','Cheif']}
   },
   {
    path:'dinein',
    loadComponent:()=>import('./pages/dinein.component').then(m=>m.DineinComponent),
    data:{dataRoles:['Admin']},
    canActivate: [RoleGuard],
   //  canActivate:[canActivateTeam]
   },{
      path:'floors',
      loadComponent:()=>import('./pages/floor-list.component').then(m=>m.FloorListComponent),
   },{
      path:'branch',
      loadComponent:()=>import('./pages/branch-list.component').then(m=>m.BranchListComponent),
   },{
      path:'categories',
      loadComponent:()=>import('./pages/categories-list.component').then(m=>m.CategoriesListComponent),
   },{
      path:'customers',
      loadComponent:()=>import('./pages/customer.component').then(m=>m.CustomerComponent),
   },{
      path:'waiter',
      loadComponent:()=>import('./pages/waiter.component').then(m=>m.WaiterComponent),
   },{
      path:'menu-list',
      loadComponent:()=>import('./pages/menu-list.component').then(m=>m.MenuListComponent),
   },{
      path:'menu-type',
      loadComponent:()=>import('./pages/menu-type.component').then(m=>m.MenuTypeComponent),
   },{
      path:'order-histroy',
      loadComponent:()=>import('./pages/order-histroy.component').then(m=>m.OrderHistroyComponent),
      canActivate: [RoleGuard],
      data:{dataRoles:['Admin','Captain','Cheif']}
   },
   {
      path:'kot-list',
      loadComponent:()=>import('./pages/kot-list.component').then(m=>m.KotListComponent),

   },
   {
      path:'order-type',
      loadComponent:()=>import('./pages/order-type.component').then(m=>m.OrderTypeComponent),
   },{
      path:'tax',
      loadComponent:()=>import('./pages/tax.component').then(m=>m.TaxComponent),
   },{
      path:'extra-charge',
      loadComponent:()=>import('./pages/extra-charge.component').then(m=>m.ExtraChargeComponent),
   },{
      path:'discount',
      loadComponent:()=>import('./pages/discount.component').then(m=>m.DiscountComponent),
   },{
      path:'tables',
      loadComponent:()=>import('./pages/table.component').then(m=>m.TableComponent),
   },{
      path:'take-away',
      loadComponent:()=>import('./pages/take-away.component').then(m=>m.TakeAwayComponent),
   },
   {
    path:'order',
    loadComponent:()=>import('./pages/order.component').then(m=>m.OrderComponent),
   },
   {
    path:'order/:tableId/:floorId/:typeId',
    loadComponent:()=>import('./pages/order.component').then(m=>m.OrderComponent),
   },
   {
    path:'order/:tableId/:floorId/:typeId/:tableName',
    loadComponent:()=>import('./pages/order.component').then(m=>m.OrderComponent),
   },{
      path:'open-close-day',
      loadComponent:()=>import('./pages/openclose-day.component').then(m=>m.OpencloseDayComponent)
   },
   {
    path:'product',
    loadComponent:()=>import('./pages/product-list.component').then(m=>m.ProductListComponent),
   //  canActivate:[canActivateTeam]
   },{
      path:'users',
      loadComponent:()=>import('./pages/users.component').then(m=>m.UsersComponent)
   }
];
