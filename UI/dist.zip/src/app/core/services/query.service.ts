import { Injectable, input } from '@angular/core';
import { catchError, from, Observable, of, tap,map } from 'rxjs';
import { restaurants,waiterList,customerList,dinein,categoryList,productList,checkLogin,menuList } from '../constants/Appsettings';
import { appSetttings } from '../constants/Appsettings';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class QueryService {

  constructor(private http:HttpClient,private auth:AuthService) { }


  customHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
    });


  postCheckLogin(params:any):Observable<any>{

     console.log('postCHeckloign');

    let request ={
      username :  params.username,
      password: params.password
    }

    return this.http.post(appSetttings + 'auth/Login',request,{
           headers:this.customHeaders
    },).pipe(
      map((response :any)=> {
        // Handle the successful login response
        // Assume the token is part of the response object
        if (response.status=='Success') {

          this.auth.setRolesToken(response.data.role,response.data.token)
          //localStorage.setItem('authToken', response.data.token);
        //  localStorage.setItem('authRole',response.data.role);
          //this.auth.setRoles(response.data.role);
        }
        return response;
      }),
      // Catch any errors during the request
      catchError((err:any)=>{
        throw err;
      })
    );
   // let response = checkLogin;
    //console.log(response);
   // return of(response);
  }

  getCategories():Observable<any>{
   return this.http.get(appSetttings+'Categories').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err
      })
    )
   // return of(categoryList);
  }

  getOpenCloseDay():Observable<any>{
    return this.http.get(appSetttings+'WorkPeriod').pipe();
  }

  postOpenDay():Observable<any>{
    return this.http.post(appSetttings+'WorkPeriod/Open',{}).pipe();
  }
  
  postCloseDay(inputId:any):Observable<any>{
    return this.http.post(appSetttings+'WorkPeriod/Close/'+inputId,{}).pipe();
  }

    getSummary(businessDate: string): Observable<any> {
    return this.http.get(appSetttings+`/api/closing/summary?businessDate=${businessDate}`);
    }


    closeDay(payload: any): Observable<any> {
    return this.http.post(appSetttings+'/api/closing/close', payload);
    }

  getUserList():Observable<any>{
    return this.http.get(appSetttings+'user').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err
      })
    )
  }


  getBranches():Observable<any>{
     return this.http.get(appSetttings+'Branches').pipe(
      map((res:any)=>{
        console.log(res,'Branch');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);       
      })
     )
  }

  createUsers(outputParams:any):Observable<any>{
    
    return this.http.post(appSetttings+'User',outputParams,{
           headers:this.customHeaders
    },
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )

  }

  updateUsers(outputParams:any):Observable<any>{
    
    return this.http.post(appSetttings+'User/UpdateUser',outputParams,{
           headers:this.customHeaders
    },
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )

  }

  updateRoles(outputParams:any):Observable<any>{
     return this.http.post(appSetttings+'User/AssignRole',outputParams,{
           headers:this.customHeaders
    },
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  

  getCustomers():Observable<any>{
    return this.http.get(appSetttings+'Customers').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
          throw err;
      })
    )
  }

  getMenus():Observable<any>{
    return this.http.get(appSetttings+'Items').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
          throw err;
      })
    )
  }

  getFoodMenuList():Observable<any>{

    return this.http.get(appSetttings+'Restaurant/GetMenu').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )

   // return of(restaurants);
  }


  getWaiters():Observable<any>{
   return this.http.get(appSetttings+'Waiter').pipe(
      tap((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )
    //return of(waiterList);
  }



  

  getDineIn():Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.get(appSetttings+'Floors').pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
   // return of(dinein);
  }


  getFloors():Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.get(appSetttings+'Floors').pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
   // return of(dinein);
  }

  getBranchList():Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.get(appSetttings+'Branches').pipe(
      map((res:any)=>{
        console.log(res,'Branch');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);       
      })
    )
   // return of(dinein);
  }

    getRoleList():Observable<any>{  
    return this.http.get(appSetttings+'Roles').pipe(
      map((res:any)=>{
        
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);       
      })
    )
   // return of(dinein);
  }

  getOrderForReport(paramObj:any):Observable<any>{

      
      return this.http.get(appSetttings+'Orders/GetOrdersForReport',{params:{
        fromDate: paramObj.fromDate.toString(),
        toDate: paramObj.toDate.toString(),
        status:paramObj.status,
        ordertypeid:paramObj.ordertypeid
      }}).pipe(
        map((res:any)=>{
          return  res;
        }),
        catchError((err:any)=>{
          throw err;
        })
      )
  }

  getBillForReport(paramObj:any):Observable<any>{

      
      return this.http.get(appSetttings+'Bill/GetBillOrderReport',{params:{
        fromDate: paramObj.fromDate.toString(),
        toDate: paramObj.toDate.toString(),
        status:paramObj.status
      }}).pipe(
        map((res:any)=>{
          return  res;
        }),
        catchError((err:any)=>{
          throw err;
        })
      )
  }

  getOrderByType(id:any):Observable<any>{
    return this.http.get(appSetttings+'Orders/GetOrderByType',{ params:{
      ordertypeid:id
      }}).pipe(
        map((res:any)=>{
          return res;
        }),
        catchError((err:any)=>{
          throw err;
        })
      )
  }

  getOrderByTableId(id: any):Observable<any>{
    return this.http.get(appSetttings+'Orders/GetOrderByTable',{params:{
      tableID:id
    }}).pipe(
      map((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )


  }


  addFloor(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Floors',outputParams,{
           headers:this.customHeaders
    },
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  updateFloor(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Floors/UpdateFloor',outputParams,{
           headers:this.customHeaders
    },
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  setOrderList(outputParams:any):Observable<any>{

    console.log(outputParams);
    return this.http.post(appSetttings+'Orders/CreateOrder',outputParams).pipe(
      map((res)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )
  }

  updateOrderList(outputParams:any):Observable<any>{

    console.log(outputParams);
    return this.http.post(appSetttings+'Orders/UpdateOrder',outputParams,{
      headers:this.customHeaders
    }).pipe(
      map((res)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )
  }

  setBillList(outputParams:any):Observable<any>{

    console.log(outputParams);
    return this.http.post(appSetttings+'Bill/CreateBill',outputParams).pipe(
      map((res)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )
  }

  

    updateBillList(outputParams:any):Observable<any>{

    console.log(outputParams);
    // return this.http.patch(`Bill/PatchBill/${billUpdate.billId}`, billUpdate);

    //  return this.http.post(appSetttings+'Bill/UpdateBill',outputParams).pipe(
    return this.http.post(appSetttings+'Bill/UpdateBill/',outputParams).pipe(
      map((res)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;
      })
    )
  }



  updateCategory(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Categories/UpdateCategory',outputParams,{      
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  addCategory(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Categories',outputParams,{      
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }


  addCustomer(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Customers',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  updateCustomer(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Customers/UpdateCustomer',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
  }

  addWaiter(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Waiter',outputParams,{
        headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }


  updateWaiter(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Waiter/UpdateWaiter',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }


  addMenu(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Items',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  updateMenu(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Items/UpdateItem',outputParams,{
     headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }
  

  addMenuType(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'MealType',outputParams,{
     headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }


  updateMenuType(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'MealType/UpdateMealType',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  
  
  
  addOrderType(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'OrderType',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  updateOrderType(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'OrderType/UpdateOrderType',outputParams,{
       headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }



  addTax(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Tax',outputParams,{      
      headers:this.customHeaders
    }).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  addExtraCharge(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Tax',outputParams,{      
      headers:this.customHeaders
    }).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

///taxid=${outputParams.taxid}
  updateTax(outputParams:any):Observable<any>{
    return this.http.post(appSetttings+'Tax/UpdateTax',outputParams,{      
      headers:this.customHeaders
    }).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }


  updateExtraCharge(outputParams:any):Observable<any>{
    return this.http.post(appSetttings+'Tax/UpdateTax',outputParams,{      
      headers:this.customHeaders
    }).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  addTable(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Tables',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  updateTable(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Tables/UpdateTable',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  updateDiscount(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Discounts/UpdateDiscount',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  addDiscount(outputParams:any):Observable<any>{

    return this.http.post(appSetttings+'Discounts',outputParams,{
      headers:this.customHeaders
    }
      ).pipe(
      map((res:any)=>{
        //console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
       // return of(null);
       
      })
    )
  }

  getTax():Observable<any>{
    return this.http.get(appSetttings+'Tax').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }


    getExtraCharges():Observable<any>{
    return this.http.get(appSetttings+'Tax').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }

  getTable():Observable<any>{
    return this.http.get(appSetttings+'Tables').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }

  getDiscounts():Observable<any>{
    return this.http.get(appSetttings+'Discounts').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }


  

  getTables():Observable<any>{
    return this.http.get(appSetttings+'Tables').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }


  getMenuTypes():Observable<any>{
    return this.http.get(appSetttings+'MealType').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }

  getOrderTypes():Observable<any>{
    return this.http.get(appSetttings+'OrderType').pipe(
      map((res:any)=>{
        return res;
      }),catchError((err:any)=>{
        throw err;
      })
    )
  }

  deleteFloor(floorId:Number):Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'Floors/DeleteFloor/'+floorId,null).pipe(
      map((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;       
      })
    )
  }


    deleteUser(userId:Number):Observable<any>{
   // console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'User/DeleteUser/'+userId,null).pipe(
      map((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;       
      })
    )
  }


 deleteRole(userId:Number):Observable<any>{
   // console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'User/DeleteAssingedRole/'+userId,null).pipe(
      map((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;       
      })
    )
  }


  deleteOrder(inputPost:any):Observable<any>{

    return this.http.post(appSetttings+'Orders/DeleteOrderById/'+inputPost.id,null);

  }


  deleteTable(tableId:Number):Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'Tables/DeleteTable/'+tableId,null).pipe(
      map((res:any)=>{
        return res;
      }),
      catchError((err:any)=>{
        throw err;       
      })
    )
  }

  deleteTax(id:Number):Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'Tax/DeleteTax/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
   // return of(dinein);
  }


    deleteExtraCharge(id:Number):Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'Tax/DeleteTax/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
   // return of(dinein);
  }

  deleteDiscount(id:Number):Observable<any>{
    console.log('dinein',appSetttings);   
    return this.http.post(appSetttings+'Discounts/DeleteDiscount/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'dinein');    
        //return of(res.data);
        return res;
      }),
      catchError((err:any)=>{
        throw err;
        return of(null);
       
      })
    )
   // return of(dinein);
  }
  

  deletecategory(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'Categories/DeleteCategory/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'categories');    
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }

  deletMenuType(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'MealType/DeleteMealType/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'categories');    
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }

  deletOrderType(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'OrderType/DeleteOrderType/'+id,null).pipe(
      map((res:any)=>{        
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }

  

  deleteWaiter(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'Waiter/DeleteWaiter/'+id,null).pipe(
      map((res:any)=>{
        //console.log(res,'categories');    
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }


  deleteMenu(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'Items/DeleteItem/'+id,null).pipe(
      map((res:any)=>{
        //console.log(res,'categories');    
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }
  

  

  deleteCustomer(id:Number):Observable<any>{ 
    return this.http.post(appSetttings+'Customers/DeleteCustomer/'+id,null).pipe(
      map((res:any)=>{
        console.log(res,'categories');    
        return res;
      }),
      catchError((err:any)=>{
        throw err;  
      })
    )
  }
  
  getMenuList():Observable<any>{
    this.http.get(appSetttings+'/').pipe(
      map((res:any)=>{

      }),
      catchError((err:any)=>{
        throw err;
      })
    )
    return of(menuList);
  }


  postCategoryList(inputParams:{CategoryName:string,IsActive:boolean}):Observable<any>{
    this.http.post(appSetttings+'/',inputParams).pipe(
      tap((res:any)=>{

      }),
      catchError((err:any)=>{
        throw err
      })
    )

    let data ={
      status:"success",
      message:"successfully submitted"
    }

    return of(data);
  }

  getProductList():Observable<any>{
    this.http.get(appSetttings+'/').pipe(
      tap((res:any)=>{

      }),
      catchError((err:any)=>{
        throw err
      })
    )
    return of(productList);
  }
  
  postProductList(inputParams:{CategoryName:string,IsActive:boolean}):Observable<any>{
    this.http.post(appSetttings+'/',inputParams).pipe(
      tap((res:any)=>{

      }),
      catchError((err:any)=>{
        throw err
      })
    )

    let data ={
      status:"success",
      message:"successfully submitted"
    }

    return of(data);
  }


}
