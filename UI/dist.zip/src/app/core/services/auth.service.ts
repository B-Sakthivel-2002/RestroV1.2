import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private roles: string[] = [];

  constructor() {
    this.loadRoles(); // Load from LocalStorage on app start
  }

  loadRoles() {
    try{

        const storedRoles = localStorage.getItem('authRole');
        console.log(storedRoles, 'storedRoles');

        if (storedRoles) {
            const parsed = JSON.parse(storedRoles);
            if (Array.isArray(parsed)){
              this.roles = parsed;
              console.log('Valid roles array:', this.roles);
            }else {
            console.log('Parsed data is not an array');
            this.roles = [];       // fallback
            }
        }

    } catch(error){
      this.roles =[];
      localStorage.removeItem('authRole');
      console.log(error,'<--error--->')
    }
  
        

      // try{
       
      // }catch(error){
      //    console.error('Invalid JSON in localStorage:', error);
      //    this.roles = [];
      // }     

      // this.roles = JSON.parse(storedRoles); // ✅ Convert back to array
      // console.log(' this.roles', this.roles);
   // }
  }

  setRoles(roles: string[]) {
    //this.roles = roles;
    if (Array.isArray(roles)) {
      this.roles = roles;
      // console.log('this.roles1',this.roles);
    } else {
      this.roles.push(roles);
      // console.log('this.roles2',this.roles);
    }
    localStorage.setItem('authRole', JSON.stringify(this.roles)); // ✅ Save in LocalStorage
  }

  setRolesToken(roles: string[], token: string) {
    this.roles = [];
    if (Array.isArray(roles)) {
      this.roles = roles;
    } else {
      this.roles.push(roles);
    }
    localStorage.setItem('authRole', JSON.stringify(this.roles));
    localStorage.setItem('authToken', token);
    localStorage.removeItem('orderHistroy');
  }

  clearRolesToken(): Observable<boolean> {
    this.roles = [];

    localStorage.clear();
    // localStorage.removeItem('orderHistory');
    // localStorage.removeItem('authRole');
    // localStorage.removeItem('authToken');
    return of(true);
  }

  hasRole(role: string): boolean {
    return this.roles.includes(role);
  }

  hasAnyRole(roles: string[]): boolean {
    return roles.some((r) => this.roles.includes(r));
  }

  clearRoles() {
    this.roles = [];
    localStorage.removeItem('user_roles'); // ✅ Clear on logout
  }
}
