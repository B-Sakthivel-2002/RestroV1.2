import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AlertService } from '@appservices/alert.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('authToken');
  const router = inject(Router);
  let authReq = req;

  //   if (req.url.includes('/')) {
  //     console.log('user-url --');
  //   return next(req);
  // }

  if (token) {
    
    authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    //return next(authReq);
  }

  return next(authReq).pipe(

    catchError((err:any)=>{
        if(err.status === 401){
          console.log('401');
        //  alert.showAlert('Failed','Unauthorized');  
           alert('Failed');
          logout(router);
          return throwError(() => err);
        }else if(err.status=='403'){          
          redirectByRole(router);   
          return throwError(()=>err);
        }
        return throwError(() => err);
    })
  )

};


function logout(router:Router){
   localStorage.clear();
   router.navigate(['/']);
}


function redirectByRole(router:Router){

  const currentRole = localStorage.getItem('authRole');
          
          switch(currentRole){
            case 'Admin':
            router.navigate(['dashboard']);
            break;
            case 'Captian':
            router.navigate(['captain']);
            break;

            default :
            router.navigate(['/']);

          }
}

  /* ----------------------------------------------------
         3️⃣ Handle 401 → Refresh Token
      ---------------------------------------------------- */
      // if (err.status === 401 && refreshToken) {
      //   return http.post<any>('/auth/refresh', {
      //     refreshToken
      //   }).pipe(
      //     switchMap(res => {
      //       localStorage.setItem('authToken', res.accessToken);

      //       const retryReq = req.clone({
      //         setHeaders: {
      //           Authorization: `Bearer ${res.accessToken}`
      //         }
      //       });

      //       return next(retryReq);
      //     }),
      //     catchError(() => {
      //       logout(router);
      //       return throwError(() => err);
      //     })
      //   );
      // }