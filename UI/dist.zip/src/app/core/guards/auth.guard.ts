import { Injectable,inject } from "@angular/core";
import { Router, CanActivateFn } from "@angular/router";
import { StorageService } from "@appservices/storage.service";



export const authGuard: CanActivateFn = () => {

  const storage = inject(StorageService);
  const router = inject(Router);
  const token = storage.getItem('authToken');

  console.log(token,'---token--auth');

  if(!token){
    return true;
  }
  return router.createUrlTree(['/dashboard']);
  return false;

}

export const afterLogged: CanActivateFn = () => {
  const storage = inject(StorageService);
  const router = inject(Router);

  const token = storage.getItem('authToken');

  if (token) {
    return true; // allow access
  }

  return router.createUrlTree(['/']); // redirect to main page
};

// export class AuthGuard implements CanActivate{

//   constructor(private storage:StorageService,private router:Router){}

//   canActivate(): boolean {
//     console.log(this.storage.getItem('authToken'),'this.storage.getItem');
//     if (!this.storage.getItem('authToken')) {      
//       return true;        // user allowed
//     }
//     this.router.navigate(['/dashboard']);
//   //  this.router.navigate(['/login']);  // redirect to login
//     return false;    
//   }
  
// }

// export class AfterLoggedGuard implements CanActivate{
//   constructor(private storage:StorageService,private router:Router){}

//   canActivate(): boolean {
//     console.log(this.storage.getItem('authToken'),'this.storage.getItem');
//     if (this.storage.getItem('authToken')) {      
//       return true;        // user allowed
//     }
//     this.router.navigate(['/login']);
//   //  this.router.navigate(['/login']);  // redirect to login
//     return false;    
//   }
  

// }