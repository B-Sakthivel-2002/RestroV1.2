export  interface CategoryType {   
    CategoryName: string;
    IsActive: boolean;
}