import {
  BsVerions,
  LinkedList,
  OnChange,
  Trigger,
  Utils,
  currentBsVersion,
  document,
  getBsVer,
  listenToTriggers,
  listenToTriggersV2,
  parseTriggers,
  registerEscClick,
  registerOutsideClick,
  setTheme,
  warnOnce,
  win
} from "./chunk-COUXPUWX.js";
import "./chunk-JYXXJTPI.js";
import "./chunk-5TID76VL.js";
export {
  BsVerions,
  LinkedList,
  OnChange,
  Trigger,
  Utils,
  currentBsVersion,
  document,
  getBsVer,
  listenToTriggers,
  listenToTriggersV2,
  parseTriggers,
  registerEscClick,
  registerOutsideClick,
  setTheme,
  warnOnce,
  win as window
};
//# sourceMappingURL=ngx-bootstrap_utils.js.map
