import { ChangeDetectorRef, Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';
import { IonicModule } from '@ionic/angular';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { QueryService } from '../core/services/query.service';
import { StorageService } from '../core/services/storage.service';
import { debounceTime, Subject, takeUntil } from 'rxjs';
import { AlertService } from '../core/services/alert.service';
import { DiscountModalComponent } from '../core/components/discount-modal/discount-modal.component';
import { SettleModalComponent } from '../core/components/settle-modal/settle-modal.component';
import { addIcons } from 'ionicons';
import { search,backspace,arrowBackCircle,arrowBack,close } from 'ionicons/icons';



@Component({
  selector: 'app-order',
  templateUrl: './order.page.html',
  styleUrls: ['./order.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,   // ✅ REQUIRED
    FormsModule,
    ReactiveFormsModule
  ],
})
export class OrderPage implements OnInit {

  

  
  
  constructor(private modalCtrl: ModalController,private router:Router,private orderLocalStorage:StorageService,private alertService:AlertService,private stateService:StorageService,private query:QueryService,private activeRoute: ActivatedRoute,private changeDetectRef:ChangeDetectorRef){
      addIcons({ search,backspace,arrowBackCircle ,arrowBack,close });
  }

   async openSettleModal() {

    // const modal = await this.modalCtrl.create({
    //   component: SettleComponent,
    // });
    // await modal.present();

  }


  tableId!:Number;
  floorId!:Number;  
  typeId!:Number;
  tableName!:String;
  customerList:any =[];
  selectedcustomerid:any =0;
  selectedwaiterid:any=0;
  selectedordertypeid:any=1;
  waiterList:any=[];
  foodMenuList:any=[];
  subMenuList:any=[];
  inputTax:any=5;
  inputDiscount:any =[];
  discountList:any =[];
  extraList:any=[];
  taxList:any =[];
  orderTypeList:any =[];
  isPrinted:boolean = false;
  updateBillId:any = -1;
  isSettle:boolean = false;
  isKOT:boolean= false;
  inputSearchMenu = new FormControl('');
  inputComment:any ='';
  inputCommentFlag:boolean = false;
  selectDiscount:any={
    id:-1,
    value:0,
    flag:'',
  }
  @ViewChild('settleTemplate') settleTemplate!: TemplateRef<any>;

  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }

  // discountModalRef?: BsModalRef;
  // settleModalRef?:BsModalRef;

  discountModalOpen = false;
  settleModalOpen = false;
  searchMenuListFlag = false;

  selectedMenuId: any;

  onMenuChange(event: any) {
    const id = event.detail.value;
    this.getSubMenuList(id);
  }

   setOpenSearchList(isOpen: boolean) {
    this.searchMenuListFlag = isOpen;
  }

  private defaultPostBill = {
    orders: [],
    lifecycleStatus:'finalized',
    totalAmount: 0,
    billAmount: 0,
    tax: 0,
    subTotalAmount: 0,
    taxList: [],
    discountList: [],
    discountid:[],
    extraList: [],
    extraAmount: 0,
    discount: 0,
    discountType: '',
    discountIndex: 0,
    discountFlag: false,
    notes: '',
    paidamount: '',
    paymentmode: 'cash',
    status: 'paid',
    iscomplementary: false,
    complementaryreason: ''
  };

  postBill:any ={...this.defaultPostBill};
  destroy$ = new Subject<void>(); 

  colorList: string[] = [
    '#037171',
    '#ee3c3f',
    '#7209b7',
    '#4361ee',
    '#f72585', 
    '#001845',
    '#231942',
    '#bc00dd',
    '#0582ca',
    '#5c6b73',
    '#216869',
    '#001c55',
  ];

  foodMenuSearchList:any =[];

  @ViewChild('customPrintOut') customPrintOut !:ElementRef;  
   

  // openModal(template: TemplateRef<void>, type: 'discount' | 'settle') {
  //       if (!template) {
  //         console.error('TemplateRef is undefined');
  //         return;
  //       }
  //       const modalRef = this.modalService.show(template);
  //       if (type === 'discount') {
  //         this.discountModalRef = modalRef;
  //       } else if(type === 'settle') {
  //         this.settleModalRef = modalRef;
  //       }
  // }

  async openModal(type: 'discount' | 'settle') {

      let component: any;

      if (type === 'discount') {
        component = DiscountModalComponent;
      } else {
        component = SettleModalComponent;
      }

      const modal = await this.modalCtrl.create({
        component: component,
        componentProps: {
          postBill: this.postBill // pass data if needed
        }
      });

      await modal.present();

      const { data } = await modal.onDidDismiss();

      if (data) {
        console.log('Modal returned:', data);
      }
    }

  onStatusChange(newStatus: string) {
    console.log('Status changed:', newStatus);
    if (newStatus === 'paid') {
      this.postBill.lifecycleStatus = 'finalized';
      this.postBill.iscomplementary =  false;
      this.postBill.complementaryreason= '';
      this.postBill.paidamount = this.postBill.billAmount; // auto set full payment
    }
    if (newStatus === 'unpaid') {
      this.postBill.lifecycleStatus = 'complementary';
      this.postBill.iscomplementary =  true;
      this.postBill.complementaryreason= '';
      this.postBill.paidamount = 0;
    }
  }
  

  print() {

      const printContents = this.customPrintOut.nativeElement.innerHTML;
      const printWindow = window.open('', '', 'width=400,height=600');

      if (printWindow) {
        const doc = printWindow.document;

        // Create HTML elements safely
        const html = doc.createElement('html');
        const head = doc.createElement('head');
        const body = doc.createElement('body');

        // Add styles
        const style = doc.createElement('style');
        style.textContent = `
          body { font-family: Arial, sans-serif; padding: 0px; font-size: 10px; }
          h2 { color: #333; }
          button,select { display: none; }  
        .order-list {
      display: flex;
      flex-direction: column;
      background: #fff;
    }

    .order-list .ls {
    display: flex;
      flex-direction: row;
      justify-content: space-between;
      padding: 5px 0px;
      font-size: 13px;
    }

    .order-list .ls h2{
    width:30%;
    font-size: 14px;
      margin: 0;
      font-weight:normal;
      }

    .order-list .ls .text-left {
      text-align: left;
    }
    .order-list .ls p {
      margin-bottom: 0px;
      width: 20%;
      text-align: right;
      font-weight: normal;
      margin-top:0;
    }

    .order-list .ls p.spl-bg {
      width: auto;
    }
    .order-list .ls p {
      margin-bottom: 0px;
      width: 20%;
      text-align: right;
      font-weight: normal;
    }
      .price-tag .ls .pr-lft h4{
      text-align:right;
    font-size:14px;
    border-top:1px solid #ccc;
    margin:0px;
    padding:10px 0px;
    font-weight:normal;
    }
    .price-tag .ls .pr-lft h4.show{
    display:block;
    }
    .price-tag .ls .pr-lft h4.hide{
    display:none;
    }
    .price-tag .ls .pr-lft h4 span{
    margin-left:10px;
    }

    .order-list .ls.hd{
    border-top:1px solid #ccc;
    padding:7px 0px;
    border-bottom:1px solid #ccc;
      }

    .price-tag .ls .pr-lft h4 span.spl{
    width: 150px;
      display: inline-block;
      font-weight:bold;
      }
      .order-list .ls.spl{
      display:none;
      }
        `;
        head.appendChild(style);

        // Set print contents
        body.innerHTML = printContents;

        // Auto-print and close after printing
        body.onload = () => {
        // console.log('onloading');
          printWindow?.print();
          printWindow?.close();
        };

        html.appendChild(head);
        html.appendChild(body);

        doc.documentElement.replaceWith(html); // replaces current empty <html> with the new one
      }
    }


  ngOnInit(): void {
    console.log('order page init');
    this.loadMasterData();
    this.getParameterValue();   
    this.searchMenuList();
  }

  loadMasterData(): void {
    this.getCustomerList();
    this.getFoodMenuList();
    this.getDiscountList();
    this.getTaxList();
    this.getorderTypeList();
    this.getExtraChargesList();
}

  getLocalOrderStorage(){

    let inputParam = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId
    }
    console.log('getLocalStorage');
    this.orderLocalStorage.getOrderDetail(inputParam).subscribe({      

      next:((res:any)=>{
        console.log(res,'-----get--local--stoorage');
        // if(res.length !=0 && res.orderDetail.length !=0){
        //   this.postBill.orders.push(res.orderDetail);
        //   this.calculatetotalprice();
        //   this.isSettle = false;
        //   this.isKOT = true;
        //  // this.calculatetotalprice();   
        // }
       console.log(res,'getLocalStorage');
      }),
      error:((err:any)=>{
        
      })

    })
  }



 setLocalOrderStorage(){
    let orderDetail = this.postBill.orders[this.postBill.orders.length-1];
    if (orderDetail.orderid) return;
    let inputParam = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId,
      orderDetail:orderDetail
    }
    this.orderLocalStorage.setOrderDetail(inputParam,true).subscribe({
      next:((res:any)=>{
        console.log(res,'setLocalStorage');
      }),
      error:((err:any)=>{        
      })
    })
  }
  

  onCustomerSelect(event:any){
    let inputValue = event.target.value;
    this.selectedcustomerid = inputValue;
  }

  // onWaiterSelect(event:any){
  //   let inputValue = event.target.value;
  //   this.selectedwaiterid = inputValue;
  // }

  onOrderTypeSelect(event:any){
    let inputValue = event.target.value;
    this.selectedordertypeid = inputValue;
  }

  onSelectedBill(ind:any){
    if (!this.postBill.orders[ind] || this.postBill.orders[ind].orderid === 0) {
      return;
    }
    this.postBill.orders[ind].flag = !this.postBill.orders[ind].flag ;    
  }

  getParameterValue(){
    this.activeRoute.paramMap.subscribe((params:any)=>{
      this.tableId = params?.get('tableId');
      this.floorId = params?.get('floorId');
      this.typeId = params?.get('typeId');
      this.tableName = params?.get('tableName');
      this.getOrderByTable(this.tableId,this.typeId);
        this.getLocalOrderStorage();
    })
  }

  getorderTypeList(){    
    //this.stateService.setLoadingState(true);
   
    this.query.getOrderTypes().subscribe({
      next:((res:any)=>{
        this.orderTypeList = res.data ?  res.data :[];
        console.log(res,'res'); 
      }),
      error:((err:any)=>{        
      }),
      //complete: () => this.stateService.setLoadingState(false)
    })
    
  }


  getCustomerList(){
      // .pipe(take(1))
      console.log(this.customerList,'<---this.customerList--->');
    this.query.getCustomers().subscribe({
      next:((res:any)=>{
        console.log(res,'res');
        this.customerList = res.data ?  res.data :[];
        if(res.status=='success'){         
          console.log(this.customerList);
        }
      }),
      error:((err:any)=>{
      })
    })
  }

  // getWaiterList(){
  //   this.query.getWaiters().subscribe({
  //     next:((res:any)=>{
  //       this.waiterList = res.data;
  //       if(res.status=='success'){          
  //         console.log(this.waiterList);
  //       }
  //     }),
  //     error:((err:any)=>{
  //     })
  //   })
  // }


  

  getFoodMenuList(){
    this.query.getFoodMenuList().subscribe({
      next:((res:any)=>{
        console.log(res,'res111');
        this.foodMenuList = res.menu;   
        this.foodMenuSearchList = this.foodMenuList.map((x:any)=>x.orderdetail).flat();
        this.getSubMenuList(this.foodMenuList[0].id);
      }),
      error:((err:any)=>{})
    })
  }

  getDiscountList(){
    this.query.getDiscounts().subscribe({
      next:((res:any)=>{
        this.discountList =  res.data ?  res.data :[];
        console.log(res,'get-discount-list');
      }),
      error:((err:any)=>{

      })
    })
  }


  // getExtrasList(){
  //   this.query.getExtraCharges().subscribe({
  //     next:((res:any)=>{
  //       this.extraList = res.data;
  //       console.log(res,'get-getExtraCharges-list');
  //     }),
  //     error:((err:any)=>{

  //     })
  //   })
  // }

  async getTaxList(){
    this.query.getTax().subscribe({
      next:(async (res:any)=>{
        console.log(res,'getTax');
        this.taxList =  res.data ?  res.data :[];
        this.postBill.taxList = this.taxList;
        this.calculatetotalprice();
      }),
      error:((err:any)=>{ })
    })
  }

  async getExtraChargesList(){
    this.query.getExtraCharges().subscribe({
      next:(async (res:any)=>{
        console.log(res,'getExtra');
        this.extraList =  res.data ?  res.data :[];
      }),
      error:((err:any)=>{ })
    })
  }

  onChangeDiscountSelect(event:any){
    const selectedValue = event.target.value;  
      if( this.discountList[selectedValue].discountname=='customize'){
          this.selectDiscount.flag = true;
      }else{
         this.selectDiscount.flag = false;
      }
  }

  onDiscountSelect(inputId: any): void {
    //const selectedValue = event.target.value;  
    const selectedValue = inputId;
   
   if(selectedValue!=-1){
    this.postBill.discountFlag = true;
   // this.postBill.discount = this.discountList[selectedValue].discountrate;    
    this.postBill.discountType = this.discountList[selectedValue].discounttype;
    this.postBill.discountIndex = Number(selectedValue);    
    this.postBill.discountid =[this.discountList[selectedValue].discountid];
    this.settleModalOpen = false;
   }else{
    this.postBill.discountFlag = false;
    this.postBill.discount =0;
    this.postBill.discountType ='';
    this.postBill.discountIndex = -1;
    this.postBill.discountid = [];
    this.selectDiscount.value = 0;
   // this.postBill.discount = 0;
   }
   this.calculatetotalprice();    
  }

  async addOrderList(InputObject: any) {
    console.log(InputObject, 'Object');
    let orderIndex = this.postBill.orders.findIndex((x: { orderid: number }) => x.orderid === 0);
    if (orderIndex !== -1) {
        let order = this.postBill.orders[orderIndex];
        let itemIndex = order.orderdetail.findIndex((x: { itemid: number }) => x.itemid === InputObject.itemid);      
        if(itemIndex !== -1){         
          this.postBill.orders[orderIndex].orderdetail[itemIndex].qty += 1;
          //this.postBill.orders[orderIndex].orderdetails[itemIndex].sumofprice += InputObject.price;
          this.postBill.orders[orderIndex].orderdetail[itemIndex].sumofprice = 
    parseFloat((this.postBill.orders[orderIndex].orderdetail[itemIndex].sumofprice + InputObject.price).toFixed(2));

        }else{          
          InputObject.qty = InputObject.qty ? InputObject.qty : 1;
          InputObject.sumofprice = InputObject.sumofprice ? InputObject.sumofprice :  InputObject.price;
          this.postBill.orders[orderIndex].orderdetail.push({...InputObject});
        }        
        order.totalprice =  order.totalprice + InputObject.price;
    } else {
        InputObject.qty = InputObject.qty ? InputObject.qty : 1;
        InputObject.sumofprice = InputObject.sumofprice ? InputObject.sumofprice :  InputObject.price;
        this.postBill.orders.push({
            orderid: 0,
            waiterid: this.selectedwaiterid,          
            tableid: this.tableId,           
            timedate: new Date().toISOString(),
            customerid: this.selectedcustomerid,
            bookingid: 0,
            ordertypeid:this.typeId,
            orderdetail: [{...InputObject}],
            totalprice: InputObject.price ,
            status: '',
            billingid: 0,
            printf:false,            
            comments:this.inputComment,
        });
    }
    this.calculatetotalprice();
    this.isSettle = false;
    this.isKOT = true;
}

substractOrder(ind:any){
  let orderIndex = this.postBill.orders.findIndex((x: { orderid: number }) => x.orderid === 0);   
  if (orderIndex !== -1) {
 let localPrice = this.postBill.orders[orderIndex].orderdetail[ind].price;	
    if(this.postBill.orders[orderIndex].orderdetail[ind].qty !=1){
        this.postBill.orders[orderIndex].orderdetail[ind].qty -= 1;        
        this.postBill.orders[orderIndex].orderdetail[ind].sumofprice = 
        parseFloat((this.postBill.orders[orderIndex].orderdetail[ind].sumofprice - localPrice).toFixed(2));    	
        this.postBill.orders[orderIndex].totalprice = parseFloat((this.postBill.orders[orderIndex].totalprice - localPrice).toFixed(2)); 
    }else{
        this.postBill.orders[orderIndex].orderdetail.splice(ind,1);
        this.postBill.orders[orderIndex].totalprice = parseFloat((this.postBill.orders[orderIndex].totalprice - localPrice).toFixed(2)); 
         console.log(this.postBill.orders[orderIndex].orderdetail.length,'---len');
         if(this.postBill.orders[orderIndex].orderdetail.length==0){
              this.postBill.orders.splice(orderIndex,1);
              this.isSettle = true;
              this.isKOT = false;
          }	
    }
    this.calculatetotalprice();
  }
}


  setNewOrder(){
    this.selectedwaiterid = localStorage.getItem('userid');
    let orderDetail = this.postBill.orders[this.postBill.orders.length-1];
    let inputParamStorage = {
      tableId : this.tableId,
      floorId: this.floorId,
      typeId: this.typeId,
    }

    if (orderDetail.orderid) return;

    orderDetail.customerid = this.selectedcustomerid ?  this.selectedcustomerid : 0;
    orderDetail.waiterid = this.selectedwaiterid ? this.selectedwaiterid:0;
    orderDetail.comments = this.inputComment;
    
    console.log(orderDetail,'set-new-orderDetail');    
    this.query.setOrderList(orderDetail).subscribe({
      next:((res:any)=>{
        if(res.status =='Success'){
          this.orderLocalStorage.setOrderDetail(inputParamStorage,false);
          this.getOrderByTable(this.tableId,this.typeId);
          this.changeDetectRef.detectChanges();  
          this.inputComment ='';
          this.alertService.showAlert('Success','KOT has been sent successfully');           
        }else{
           this.inputComment ='';
           this.alertService.showAlert('Error !','KOT has not been sent. Kindly check and resend.');
          //this.isKOT = false;
          //this.isSettle = false;
        }
        console.log(res,'result');
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message)
        console.log(err,'set New Order ')
      })

    })
  }
  //Cash / UPI / Card / Split

  setPrintBill(){
      this.postBill.lifecycleStatus = 'printed';
      this.postBill.iscomplementary =  false;
      this.postBill.complementaryreason= '';
      this.postBill.status ='unpaid';
      this.postBill.paidamount=null;
      this.postBill.notes=null;
      this.setNewBill();
  }

  async setNewBill(lifeStatus?: any){

      //taxList :this.postBill.taxList,
      // discountList:this.postBill.discountList,
      //extraList:this.postBill.extraList

    // if(lifeStatus=='Printed'){
    //   this.postBill.lifecycleStatus = 'Printed';
    //   this.postBill.status ='unpaid';
    // }

    console.log(this.postBill.discountid,'this.postBill.discountid');
    // this.postBill.status+
    let createBillObj = {
      billId: 0,
      lifecycleStatus: this.postBill.lifecycleStatus,
      dateTime: new Date().toISOString(),
      customerid: this.selectedcustomerid,
      phone: '',
      address: '',
      billname: '',
      gstin: '',
      comments: '',
      totalamount: this.postBill.totalAmount ,
      billamount: this.postBill.billAmount,
      tax: this.postBill.tax,
      extraamount: this.postBill.extraAmount,
      discount: this.postBill.discount,
      discountid:this.postBill.discountid,      
      orderids: [],
      taxid :[],
      extraid:[],
      subtotal:this.postBill.subTotalAmount,      
      paidamount:this.postBill.paidamount ? this.postBill.paidamount : null,
      paymentmode:this.postBill.paymentmode ? this.postBill.paymentmode : null,
      status:this.postBill.status,
	    notes:this.postBill.notes,
      iscomplementary:this.postBill.iscomplementary,
      complementaryreason:this.postBill.complementaryreason	    
    }

    console.log(this.postBill.orders,'this.postBill.orders');

    createBillObj.orderids = this.postBill.orders.filter((x: any) => x.flag).map((x: any) => x.orderid);
    createBillObj.taxid = this.postBill.taxList.map((x:any)=>x.taxid);
    //createBillObj.extraid = this.postBill.taxList.map((x:any)=>x.taxid);


    console.log(this.postBill.orders,createBillObj.orderids,createBillObj,'createBillObj.orderids');
     
    //return;
    //return;//
    this.query.setBillList(createBillObj).subscribe({
      next:(async(res:any)=>{
        console.log(res,'result of bill list')

        if(res.status=='Success'){
          await this.resetPostBill();
          //this.getOrderByTable(this.tableId,this.typeId);
          this.redirectRoutePage();
          this.alertService.showAlert('Success','Bill has been created successfully');
        }else{
          this.alertService.showAlert('Error','Bill has not created Please try again.');
        }
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message);
      })
    })
  }

redirectRoutePage() {
  console.log(this.typeId,'---swithc');
  if(this.typeId==1){
 this.router.navigate(['/dinein']);
  }else if(this.typeId==2){
 this.router.navigate(['/take-away']);
  }else if(this.typeId==3){
     this.router.navigate(['/home-delivery']);
  }
  else{
this.router.navigate(['/']); // fallback route
  }
}

  async updateNewBill(inputBillId: any){

    let updateBillObj = {
      billId: inputBillId,
      lifecycleStatus: this.postBill.lifecycleStatus,
      paidamount:this.postBill.paidamount ? this.postBill.paidamount : null,
      paymentmode:this.postBill.paymentmode ? this.postBill.paymentmode : null,
      status:this.postBill.status,
	    notes:this.postBill.notes,
      iscomplementary:this.postBill.iscomplementary,
      complementaryreason:this.postBill.complementaryreason	,
      orderids:[]   
    }

     updateBillObj.orderids = this.postBill.orders.filter((x: any) => x.flag).map((x: any) => x.orderid);
   
    this.query.updateBillList(updateBillObj).subscribe({
      next:(async(res:any)=>{
	  
        console.log(res,'result of bill list')
        if(res.status=='Success'){
          await this.resetPostBill();
          this.redirectRoutePage();
         // this.router.navigate(['/dinein']);
         // this.getOrderByTable(this.tableId,this.typeId);
          this.alertService.showAlert('Success','Bill has been updated successfully');
        }else{
          this.alertService.showAlert('Error','Bill has not updated Please try again.');
        }
      }),
      error:((err:any)=>{
        this.alertService.showAlert('Error',err.error.message);
      })
    })
  }

  searchMenuList(){
    // this.inputSearchMenu.valueChanges.pipe(debounceTime(100)).subscribe((x:any)=>{
    //   this.getSubMenuListBySearch(this.inputSearchMenu);
    // })

     this.inputSearchMenu.valueChanges
    .pipe(debounceTime(300), takeUntil(this.destroy$))
    .subscribe((value: any) => {
      console.log(value,'---value--');
      this.getSubMenuListBySearch(value);
    });
  }

  resetPostBill() {
    this.postBill = { ...this.defaultPostBill };
    // this.postBill.orders=[];
    // this.postBill.totalAmount =0;
    // this.postBill.billAmount =0;
    // this.postBill.subTotalAmount =0;
    // this.postBill.tax=0;
    this.selectDiscount.value =0;
    this.selectDiscount.id =-1;
    this.selectDiscount.flag = false;
  }

  async getOrderByTable(id:any,typeId:Number){
    if (!id || !typeId) return; // ✅ guard
   // this.stateService.setLoadingState(true);
    this.postBill.orders =[];

    let localGetOrder ;

    if(typeId == 1){
      localGetOrder =  this.query.getOrderByTableId(id);      
    }else{
      localGetOrder =  this.query.getOrderByType(typeId);
    }
    console.log(localGetOrder,'--localGetOrder--');

    localGetOrder.subscribe({
      next:((res:any)=>{

        if(res.status=='Success'){
          console.log(res,'get-order-by-table--')
          this.postBill.orders = res.data.map((x:any)=>{
            return {...x,flag:true}
          });


           this.postBill.orders = res.data.map((x:any)=>{
              if(x.status=='printed'){
                this.isPrinted =  true;
                this.updateBillId = x.billingid;
              }
              return {...x,flag:true}
          });

          console.log(this.postBill.orders)
          this.isSettle = true;
          this.isKOT = false;  
          this.calculatetotalprice();  
          if(this.isPrinted)        {
            //this.openModal('settle')
          }
          this.changeDetectRef.detectChanges();
                
        }else{

        }
        
       // this.stateService.setLoadingState(false);
        console.log(res,'getOrderBy Table ')
      }),
      error:((err:any)=>{
       // this.stateService.setLoadingState(false);
      })

    })
     
  }

  async calculatetotalprice() {  
    console.log(this.postBill.orders,'---otfd--');

    if (!Array.isArray(this.postBill.orders)) {
      console.error("postBill.orders is not an array!");
    }

    let localtotalprice = this.postBill.orders.reduce((sum: number, order: any) => {
      let price = Number(order.totalprice) || 0; // Ensure it's a valid number
      console.log(sum, price, 'totalprice');
      return sum + price;
    }, 0);
    // Round to 2 decimal places
   
    this.postBill.subTotalAmount = parseFloat(localtotalprice.toFixed(2));

     if (this.taxList.length && localtotalprice) {
      let localTaxAmount =0;
      await this.taxList.forEach((x: any) => {       
        const inRange = x.taxrangestatus ? (x.taxfrom <= localtotalprice && x.taxto >= localtotalprice) : true;
        if (!inRange) return;
        let taxAmount = 0;
        if (x.taxtype === 'percentage') {
          taxAmount = (localtotalprice * x.taxrate) / 100;
        } else if (x.taxtype === 'flat') {
          taxAmount = x.taxrate;
        }
        if(taxAmount){
         localtotalprice += Number(taxAmount) || 0;
         localTaxAmount += Number(taxAmount) || 0;
        }
      });
       this.postBill.tax =  parseFloat(localTaxAmount.toFixed(2));
    }


    if( this.postBill.discountFlag){
      //let localDiscount.valueAmount =0;
      let discountObject = await this.discountList[this.postBill.discountIndex]; 

      console.log(discountObject,'discountObject');

      if(discountObject.discountname=='customize'){
              this.postBill.discount =  Number(this.selectDiscount.value).toFixed(2) || 0 ;
              this.postBill.discountList = discountObject;  
              localtotalprice -= Number(this.selectDiscount.value)|| 0;
      }else{
          let discountRangeStatus = discountObject.discountrangestatus ?  (discountObject.discountfrom <= localtotalprice && discountObject.discountto >= localtotalprice) : true;
         
          if (discountRangeStatus) {
              let discountAmount =0;
                if(discountObject.discounttype=='percentage'){
                      discountAmount = ((localtotalprice * discountObject.discountrate) /100 );                       
                }else if(discountObject.discounttype =='flat'){
                        discountAmount = discountObject.discountrate;
                }
              localtotalprice -= Number(discountAmount)|| 0;
              this.postBill.discount =  Number(discountAmount).toFixed(2) || 0 ;
              this.postBill.discountList = discountObject;
          } 
      }      
    }

    /*extralist*/
   console.log(this.extraList,'--testing ---extralist--');
  
    if (this.extraList.length && localtotalprice) {


      let localextraAmount =0;
      await this.extraList.forEach((x: any) => {  
          console.log(this.extraList,x.ordertypeid,)
          if(this.typeId==x.ordertypeid){
              const inRange = x.extrachargestatus ? (x.extrachargefrom <= localtotalprice && x.extrachargeto >= localtotalprice) : true;
              if (!inRange) return;
              let extraAmount = 0;              
              if (x.extrachargetype === 'percentage') {
                extraAmount = (localtotalprice * x.extrachargerate) / 100;
              } else if (x.extrachargetype === 'flat') {
                extraAmount = x.extrachargerate;
              }
              if(extraAmount){
              localtotalprice += Number(extraAmount) || 0;
              localextraAmount += Number(extraAmount) || 0;
              }            
          }
        });
    
        this.postBill.extraAmount =  parseFloat(localextraAmount.toFixed(2));

    }


    this.postBill.taxList =this.taxList;
    this.postBill.totalAmount = parseFloat(localtotalprice.toFixed());
    this.postBill.billAmount = parseFloat(localtotalprice.toFixed());
    this.postBill.paidamount = parseFloat(localtotalprice.toFixed());
    
  }


  redirectToHome(){
    this.router.navigate(['/tabs/dinein']);
  }


  async removeOrderList(Obj:any){
    this.postBill.orders[0].items.findIndex((x:any)=>x.itemID==Obj.id);
  }


  getSubMenuList(id:Number){

    console.log(id,'submenu-list',this.foodMenuList);
    let getFoodMenuList:any = {};    
    
    const index = this.foodMenuList.findIndex((x: any) => x.id === id);
    getFoodMenuList = index !== -1 ? { data: this.foodMenuList[index], index } : null; 
    
    this.foodMenuList.filter((x:any)=>x.flag = false);    
    this.foodMenuList[getFoodMenuList.index].flag = true;
    this.subMenuList = getFoodMenuList.data.orderdetail;
    //this.foodMenuList
  }


  getSubMenuListBySearch(searchText:any){    
    console.log(searchText,'searchText');
    let inputSearchText =  searchText.toLowerCase();
    console.log(inputSearchText);
    let searchMenuList = this.foodMenuSearchList.filter((y:any)=>{
     if(y.name.toLowerCase().includes(inputSearchText) || y.code?.includes(inputSearchText)){
      return y;
     }
    });

     this.subMenuList = searchMenuList;
    // if(searchMenuList.length !=0){
     
    // }    
    console.log(searchMenuList,inputSearchText)
    console.log(searchMenuList,'allF');


  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

}
