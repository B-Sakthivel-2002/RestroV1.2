import { Routes } from '@angular/router';

export const routes: Routes = [
 
  {
    path: '',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage)
  },
  {
    path:'order',
    loadComponent:()=>import('./order/order.page').then(m=>m.OrderPage),
   },
   {
    path:'order/:tableId/:floorId/:typeId',
    loadComponent:()=>import('./order/order.page').then(m=>m.OrderPage),
   },
   {
    path:'order/:tableId/:floorId/:typeId/:tableName',
    loadComponent:()=>import('./order/order.page').then(m=>m.OrderPage),
   },
   {
    path: '',
    loadChildren: () => import('./tabs/tabs.routes').then((m) => m.routes),
  },
];
