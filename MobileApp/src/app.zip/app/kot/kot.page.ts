import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { FormsModule } from '@angular/forms';

import {
  AlertController,
  IonicModule,
  LoadingController
} from '@ionic/angular';

import { ActivatedRoute } from '@angular/router';

import { finalize } from 'rxjs';

import { QueryService } from '../core/services/query.service';
import { AlertService } from '../core/services/alert.service'; 
//import { StateService } from '@appservices/state.service';
// import { KotSignalrService } from '@appservices/kot-signalr.service';

interface OrderDetail {
  orderdetailid: number;
  qty: number;
  price: number;
  kotStatus: string;
  itemName: string;
  sumofprice: number;
  isSelected?: boolean;
  name:string;
}

interface Order {
  orderid: number;
  waiter: string;
  status: string;
  businessdate: string;
  orderTypeName: string;
  visiblecount: number;
  totalprice:number;
  orderdetails: OrderDetail[];
}

@Component({
  selector: 'app-kot',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ],
  templateUrl: './kot.page.html',
  styleUrls: ['./kot.page.scss']
})
export class KotPage implements OnInit {

  orderList: Order[] = [];

  inputFromDate: string = '';
  inputToDate: string = '';

  inputComments: string = '';

  inputComplementary: boolean = false;

  visibleCount: number = 3;

  inputStatus: string = 'submitted';

  inputType: number = 0;

  dateInvalid: boolean = false;

  isCaptain: boolean = false;

  todayStr: string = '';

  orderTypeList: any[] = [];

  orderDetail: any = '';

  orderLocalDetail: any = '';

  orderDetailStatus: string = '';

  statusClass: { [key: string]: string } = {
    readytoserve: 'kot-row-read',
    submitted: 'kot-row-pickedup'
  };

  loading: HTMLIonLoadingElement | null = null;

  constructor(
    private route: ActivatedRoute,
    private query: QueryService,
    // private stateService: StateService,
    // private alertService: AlertService,
    // private signalR: KotSignalrService,
    private changeDetectorRef: ChangeDetectorRef,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) {}

  ngOnInit(): void {

    const today = new Date();

    this.todayStr = today.toISOString().split('T')[0];

    this.inputFromDate = this.formatDate(today);

    this.inputToDate = this.formatDate(today);

    this.route.params.subscribe((params: any) => {

      this.isCaptain =
        params['type'] === 'captain';

    });

    this.getOrderInit();
    
  }

  ionViewWillEnter() {
    this.getOrderInit();
  }

  formatDate(date: Date): string {

    const year = date.getFullYear();

    const month =
      ('0' + (date.getMonth() + 1)).slice(-2);

    const day =
      ('0' + date.getDate()).slice(-2);

    return `${year}-${month}-${day}`;
  }

  async showLoading() {

    this.loading = await this.loadingController.create({
      message: 'Please wait...'
    });

    await this.loading.present();
  }

  async hideLoading() {

    if (this.loading) {
      await this.loading.dismiss();
    }
  }

  async showMessage(
    header: string,
    message: string
  ) {

    const alert =
      await this.alertController.create({
        header,
        message,
        buttons: ['OK']
      });

    await alert.present();
  }

  blockTyping(event: KeyboardEvent) {

    const allowedKeys = [
      'ArrowUp',
      'ArrowDown',
      'Tab',
      'Shift',
      'Control'
    ];

    if (!allowedKeys.includes(event.key)) {
      event.preventDefault();
    }
  }

  onLoadMore(index: number) {

    const order = this.orderList[index];

    order.visiblecount =
      order.visiblecount <
      order.orderdetails.length
        ? order.orderdetails.length
        : this.visibleCount;
  }

  getStatus(status: string): string {

    return status === 'submitted'
      ? 'In Progress'
      : status === 'approved'
      ? 'Closed'
      : status === 'cancelled'
      ? 'Cancelled'
      : '';
  }

  onClickServe(
    baseIndex: number,
    subIndex: number,
    type: string = 'serve'
  ) {

    let status =
      type === 'serve'
        ? 'readytoserve'
        : 'submitted';

    if (type === 'serve') {

      this.orderList[baseIndex]
        .orderdetails[subIndex]
        .kotStatus = 'readytoserve';

    } else if (type === 'pickup') {

      this.orderList[baseIndex]
        .orderdetails[subIndex]
        .kotStatus = 'submitted';
    }

    this.onReadyToServe(
      this.orderList[baseIndex]
        .orderdetails[subIndex]
        .orderdetailid,
      status
    );
  }

  onQtyChange(index: number) {

    let qty = Number(
      this.orderLocalDetail
        .orderdetails[index].qty
    );

    if (isNaN(qty) || qty < 1) {
      qty = 1;
    }

    if (qty > 100) {
      qty = 100;
    }

    this.orderLocalDetail
      .orderdetails[index]
      .qty = qty;

    this.updateOrderDetail();
  }

  onInputDateValid() {

    if (
      new Date(this.inputFromDate) >
      new Date(this.inputToDate)
    ) {

      this.dateInvalid = true;

    } else {

      this.dateInvalid = false;
    }
  }

  updateOrderDetail() {

    let total = 0;

    let orderdetails =
      this.orderLocalDetail.orderdetails.map(
        (x: any) => {

          x.sumofprice =
            x.price * x.qty;

          total += x.sumofprice;

          return x;
        }
      );

    this.orderLocalDetail = {
      ...this.orderLocalDetail,
      orderdetails,
      totalprice: total.toFixed(2)
    };
  }

  onResetOrder() {

    this.orderLocalDetail =
      structuredClone(this.orderDetail);
  }

  onStatusChange(value: string) {

    this.inputStatus = value;
  }

  onPartialDelete(index: number) {

    if (
      this.orderLocalDetail.orderdetails.length !== 1
    ) {

      this.orderLocalDetail.totalprice =
        (
          this.orderLocalDetail.totalprice -
          this.orderLocalDetail.orderdetails[index].price
        ).toFixed(2);

      this.orderLocalDetail
        .orderdetails
        .splice(index, 1);
    }
  }

  onOrderTypeChange(value: number) {

    this.inputType = value;
  }

  getOrderInit() {

    this.getOrderReport();
  }

  getTimeAgo(dateString: string): string {

    const inputDate = new Date(dateString);

    const now = new Date();

    const diff =
      now.getTime() - inputDate.getTime();

    const minutes =
      Math.floor(diff / (1000 * 60));

    const hours =
      Math.floor(diff / (1000 * 60 * 60));

    const days =
      Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days > 0) {
      return `${days} day ago`;
    }

    if (hours > 0) {
      return `${hours} hour ago`;
    }

    if (minutes > 0) {
      return `${minutes} minute ago`;
    }

    return 'Just now';
  }

  getAllReport(status: any) {

    this.inputStatus = String(status);

    this.getOrderReport();
  }

  async getOrderReport() {

    //await this.showLoading();

    const payload = {
      fromDate: this.inputFromDate,
      toDate: this.inputToDate,
      status: this.inputStatus,
      ordertypeid: this.inputType
    };

    this.query
      .GetOrdersForKOTReport(payload)
      .pipe(
        finalize(async () => {
          await this.hideLoading();
        })
      )
      .subscribe({

        next: (res: any) => {

          this.orderList =
            res.data?.map((item: any) => ({

              ...item,

              visiblecount: 3,

              orderdetails:
                (item.orderdetails || []).map(
                  (d: any) => ({

                    orderdetailid:
                      d.orderdetailid,

                    qty: d.qty,

                    price: d.price,

                    kotStatus:
                      d.kotStatus,

                    itemName:
                      d.itemName,

                    sumofprice:
                      d.sumofprice
                  })
                )
            })) || [];

          //this.hideLoading();
        },

        error: async () => {

          await this.showMessage(
            'Error',
            'Failed to load orders'
          );
        }
      });
  }

  onEditOrder() {

    this.query
      .updateOrderList(this.orderLocalDetail)
      .pipe(
        finalize(() => {})
      )
      .subscribe({

        next: async () => {

          await this.showMessage(
            'Success',
            'Order updated successfully'
          );

          this.getOrderReport();
        },

        error: async (err: any) => {

          await this.showMessage(
            'Error',
            err?.error ||
            'Something went wrong'
          );
        }
      });
  }

  onSelectItem(
    order: any,
    item: any,
    event: any
  ) {

    if (
      event instanceof MouseEvent &&
      event.ctrlKey
    ) {

      item.isSelected =
        !item.isSelected;

    } else {

      order.orderdetails.forEach(
        (x: any) =>
          x.isSelected = false
      );

      item.isSelected = true;
    }
  }

  toggleItemSelection(
    order: any,
    item: any
  ) {

    item.isSelected =
      !item.isSelected;

    order.orderdetails.forEach(
      (x: any) => {

        if (x !== item) {
          x.isSelected = false;
        }
      }
    );
  }

  hasSelectedItem(order: any): boolean {

    return order.orderdetails.some(
      (x: any) => x.isSelected
    );
  }

  getItemRowClass(item: any) {

    if (
      item.kotStatus === 'readytoserve'
    ) {
      return 'kot-row-ready';
    }

    if (
      item.kotStatus === 'submitted'
    ) {
      return 'kot-row-pickedup';
    }

    if (item.isSelected) {
      return 'kot-row-selected';
    }

    return 'kot-row-pending';
  }

  getKOTColor(
    kotStatus: string | null
  ): string {

    switch (kotStatus) {

      case 'readytoserve':
        return 'success';

      case 'inprogress':
        return 'warning';

      case 'cancelled':
        return 'danger';

      default:
        return 'medium';
    }
  }

  onReadyToServe(
    orderDetailId: number,
    inputStatus: string
  ) {

    const payload = {
      orderDetailId,
      kotStatus: inputStatus
    };

    this.query
      .updateKOTItemStatus(payload)
      .subscribe({

        next: async () => {

          await this.showMessage(
            'Success',
            'Status updated'
          );
        },

        error: async () => {

          await this.showMessage(
            'Error',
            'Failed to update status'
          );
        }
      });
  }
}