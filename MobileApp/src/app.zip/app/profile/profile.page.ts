import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonButton } from '@ionic/angular/standalone';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { AuthService } from '../core/services/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-profile',
  templateUrl: 'profile.page.html',
  styleUrls: ['profile.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent,IonButton],
})
export class ProfilePage {
  constructor( private auth: AuthService, private router: Router) {}

  logout(){

    this.auth.clearRolesToken().subscribe({
      next:((res:any)=>{

        if(res){
          this.router.navigate(['/']);
        }

      }),
      error:((err:any)=>{

        // this.alert

      })

    })

  }

}
