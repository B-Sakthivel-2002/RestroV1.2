import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonToolbar,IonItem, IonTitle, IonContent, IonInput, IonButton, IonText, IonGrid, IonRow, IonCol, IonIcon } from '@ionic/angular/standalone';
import { AlertController } from '@ionic/angular';
import { QueryService } from '../core/services/query.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [
    IonTitle, IonContent,
    IonText, IonInput, IonButton,
    FormsModule, IonGrid, IonRow,   
    IonCol,IonItem,IonIcon
],
})
export class LoginPage {

  showPassword = false;

  username: string = '';
  password: string = '';
  submitted = false;
  loginError = false;
  errorMessage  = '';

  constructor(private alertController: AlertController,private router: Router,private queryService: QueryService) {}

  login() {
    console.log(this.username, this.password);
    this.submitted = true;
    this.loginError = false;

    // Validation
    if (!this.username || !this.password) {
      return;
    }


     let requestParam={
      username: this.username,
      password:this.password
    }

        this.queryService.validateLogin(requestParam).subscribe({
     
      next:(async (res:any)=>{    
        this.errorMessage='';
        if(res.status=='Success'){
          localStorage.setItem('userid', res.data.id);
          this.router.navigate(['/tabs/dinein']);
        }else if(res.status=='Error'){
            this.errorMessage=res.message;
             this.showLoginError(this.errorMessage);
        }
        ///this.stateService.setLoadingState(false);
     
      }),
      error:((err:any)=>{
        console.log(err);
        this.showLoginError(err.message || 'An error occurred during login. Please try again.');

        //this.stateService.setLoadingState(false);
     
      })
    })

  


    // if (this.username === 'admin' && this.password === '1234') {
    //   this.router.navigate(['/tabs/tab1']);
    // } else {
    //   this.loginError = true;
    // }


  }

  async showLoginError(message: string) {
  const alert = await this.alertController.create({
    header: 'Login Failed',
    message: message,
    buttons: ['OK']
  });

  await alert.present();
}

    clear(){
      this.username='';
      this.password='';
      this.errorMessage='';
    }
}