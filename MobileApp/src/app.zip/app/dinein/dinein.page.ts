import { Component, OnInit } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { QueryService } from '../core/services/query.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { IonIcon } from '@ionic/angular/standalone';

import {
  addIcons
} from 'ionicons';

import {
  restaurantOutline,
  chevronForwardOutline
} from 'ionicons/icons';


@Component({
  selector: 'app-dinein',
  templateUrl: 'dinein.page.html',
  styleUrls: ['dinein.page.scss'],
  imports: [FormsModule,CommonModule,IonicModule],
   
})
export class DineinPage implements OnInit {

   constructor(private query: QueryService, private router: Router) {
     addIcons({
      'restaurant-outline': restaurantOutline,
      'chevron-forward-outline': chevronForwardOutline
     });
   }

  floorSource: any[] = [];
  tablesSource: any[] = [];
  selectedFloor: any;

  ngOnInit(): void {
    console.log('DineIn Page');
    this.getFloorsList();
    this.getTables();
  }

  onFloorChange(event: any) {
    this.selectedFloor = event.detail.value;
  }

    ionViewWillEnter() {
    this.getTables(); // every time tab opens
  }

  getFloorsList() {
    this.query.getFloors().subscribe({
      next: (res: any) => {
        this.floorSource = res.data || [];
        if (this.floorSource.length) {
          this.selectedFloor = this.floorSource[0].floorid;
        }
      }
    });
  }

  getTables() {
    this.query.getTables().subscribe({
      next: (res: any) => {
        this.tablesSource = res.data || [];
      }
    });
  }

  onHandleDineIn(id: Number, floor: Number, tablename: String) {
    this.router.navigate(['/order', id, floor, 1, tablename]);
  }

  

}
