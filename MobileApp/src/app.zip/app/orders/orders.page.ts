import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs';

import { IonicModule, AlertController, ToastController } from '@ionic/angular';


import { QueryService } from '../core/services/query.service';

import { AlertService } from '../core/services/alert.service'; 
import { addIcons } from 'ionicons';
import { search,backspace,arrowBackCircle,arrowBack,close,filterOutline,closeOutline } from 'ionicons/icons';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
  templateUrl: './orders.page.html',
  styleUrls: ['./orders.page.scss']
})
export class OrdersPage implements OnInit {

  // =======================
  // VARIABLES
  // =======================
  orderList: any[] = [];
  orderTypeList: any[] = [];

  inputFromDate = '';
  inputToDate = '';
  todayStr = '';

  inputStatus: any = 'all';
  inputType: any = 0;

  dateInvalid = false;

  orderDetail: any = '';
  orderLocalDetail: any = '';
  orderDetailStatus = '';

  inputComments = '';
  inputComplementary = false;

  isModalOpen = false;
      showFilter = false;

  debounceTimer: any;

  constructor(
    private route: ActivatedRoute,
    private query: QueryService,
    private cdr: ChangeDetectorRef,
    private alertService: AlertService,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController
  ) {
     addIcons({ search,backspace,arrowBackCircle ,arrowBack,close,filterOutline,closeOutline });
  }

  // =======================
  // INIT
  // =======================
  ngOnInit(): void {

    const today = new Date();




    this.todayStr = this.formatDate(today);
    this.inputFromDate = this.todayStr;
    this.inputToDate = this.todayStr;

    this.getorderTypeList();

    this.route.queryParams.subscribe((params: any) => {

      const status = params['status'];
      const paramDate = params['date'];

      if (status && paramDate) {

        const formattedDate = paramDate.includes('T')
          ? paramDate.split('T')[0]
          : paramDate;

        this.inputFromDate = formattedDate;
        this.inputToDate = formattedDate;
        this.inputStatus = status;
      }

      this.getOrderReport();
    });
  }

  // =======================
  // COMMON
  // =======================
  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);

    return `${year}-${month}-${day}`;
  }

  toggleFilter(){
    this.showFilter = !this.showFilter;
  }

  getTimeAgo(dateString: string): string {

    const inputDate = new Date(dateString);
    const now = new Date();

    const diff = now.getTime() - inputDate.getTime();

    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;

    return 'Just now';
  }

  // =======================
  // FILTER EVENTS
  // =======================
  onInputDateValid() {

    this.dateInvalid =
      new Date(this.inputFromDate) > new Date(this.inputToDate);

    this.cdr.detectChanges();
  }

  onStatusChange(value: any) {
    this.inputStatus = value;
  }

  onOrderTypeChange(value: any) {
    this.inputType = value;
  }

  getOrderTypeName(inputType:number){
    let output = this.orderTypeList.find(x=>x.ordertypeid);
    console.log(output,'oooo');
    return output ? output.ordertypename :'';
  }

  // =======================
  // API CALLS
  // =======================
  getorderTypeList() {

    this.query.getOrderTypes().subscribe({

      next: (res: any) => {

        this.orderTypeList = res.data || [];

        this.orderTypeList.unshift({
          ordertypeid: 0,
          ordertypename: 'All Order Type'
        });

        this.inputType = 0;
      },

      error: (err: any) => {
        console.error(err);
      }
    });
  }

  getOrderReport() {



    const payload = {
      fromDate: this.inputFromDate,
      toDate: this.inputToDate,
      status: this.inputStatus,
      ordertypeid: this.inputType
    };

    this.query.getOrderForReport(payload).subscribe({

      next: (res: any) => {

        this.orderList = res.data || [];


        
        this.cdr.detectChanges();
      },

      error: () => {

        
      }
    });
  }

  // =======================
  // MODAL
  // =======================
  openModal(item: any, type: string) {

    this.orderDetail = item;
    this.orderLocalDetail = structuredClone(item);
    this.orderDetailStatus = type;

    this.inputComments = '';

    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  onResetOrder() {
    this.orderLocalDetail = structuredClone(this.orderDetail);
  }

  // =======================
  // QTY UPDATE
  // =======================
  onQtyChange(index: number) {

    let qty = Number(this.orderLocalDetail.orderdetail[index].qty);

    if (qty < 1 || isNaN(qty)) qty = 1;
    if (qty > 100) qty = 100;

    this.orderLocalDetail.orderdetail[index].qty = qty;

    this.updateOrderDetail();
  }

  updateOrderDetail() {

    let total = 0;

    this.orderLocalDetail.orderdetail =
      this.orderLocalDetail.orderdetail.map((x: any) => {

        x.sumofprice = x.price * x.qty;
        total += x.sumofprice;

        return x;
      });

    this.orderLocalDetail.totalprice = total.toFixed(2);

    this.cdr.detectChanges();
  }

  onPartialDelete(index: number) {

    if (this.orderLocalDetail.orderdetail.length === 1) return;

    this.orderLocalDetail.orderdetail.splice(index, 1);

    this.updateOrderDetail();
  }

  // =======================
  // DELETE ORDER
  // =======================
  onDeleteOrder(id: any) {

    const payload = {
      id,
      comments: this.inputComments,
      complementary: this.inputComplementary
    };

    this.query.deleteOrder(payload).subscribe({

      next: async () => {

        this.closeModal();
        this.getOrderReport();

        this.alertService.showAlert(
          'Success',
          'Order has been cancelled'
        );
      },

      error: async () => {

        this.alertService.showAlert(
          'Error',
          'Order has not been cancelled'
        );
      }
    });
  }

  // =======================
  // EDIT ORDER
  // =======================
  onEditOrder(id:number) {

    console.log(id,'id');
    this.query.updateOrderList(this.orderLocalDetail)
      .pipe(
        finalize(() => {
       
        })
      )
      .subscribe({

        next: () => {

          this.closeModal();
          this.getOrderReport();

          this.alertService.showAlert(
            'Updated!',
            'Order has been updated'
          );
        },

        error: (err: any) => {

          this.alertService.showAlert(
            'Error!',
            err?.error || 'Something went wrong'
          );
        }
      });
  }

}